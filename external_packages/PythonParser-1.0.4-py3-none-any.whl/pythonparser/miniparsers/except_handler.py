from astroid.nodes import ExceptHandler
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.exception_handler import ExceptionHandler


def parse_except_handler(node: ExceptHandler, container: Container) -> BaseNode:
    """Miniparser for Astroid's Exception Handler nodes.
    The extracted information are saved in the ExceptionHandler node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: ExceptHandler
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = ExceptionHandler()
    data_model.initialization(container, node)

    if node.name:
        data_model.alias = node.name.name

    if node.type:
        try:
            data_model.name = node.type.name

        except Exception:
            data_model.name = node.type.as_string()

    for statement in node.body:
        parsed_statement = data_model.parse_node(statement)
        data_model.statements.append(parsed_statement)

    data_model.final_operations()
    return data_model
