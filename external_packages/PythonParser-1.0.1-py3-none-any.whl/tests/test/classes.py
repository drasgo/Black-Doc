class test:
    var1 = 1
    var2: str = "test"
    var3: bool

    def __init__(self, arg1):
        self.obj1 = 1
        self.obj2 = arg1

    def func(self):
        self.obj3 = False
