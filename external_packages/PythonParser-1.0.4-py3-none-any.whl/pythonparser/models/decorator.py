from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Decorator(BaseNode):
    decorators: List[str] = field(default_factory=list)
    genus: str = "decorator"
    element_categories: List[str] = field(
        default_factory=lambda: ["class", "method", "functional"]
    )

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"decorator{('s' if len(self.decorators) > 1 else '')}: "
        for dec in self.decorators:
            humanized += f"££{dec}££, "
        humanized = humanized[:-2]
        return humanized
