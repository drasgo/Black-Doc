import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.slice import Slice


def parse_slice(node: astroid.nodes.Slice, container: Container) -> BaseNode:
    """Miniparser for Astroid's Slice node.
    The extracted information are saved in the Slice node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.Slice
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Slice()
    data_model.initialization(container, node)

    data_model.start = data_model.parse_node(node.lower)
    data_model.end = data_model.parse_node(node.upper)
    data_model.step = data_model.parse_node(node.step)

    data_model.final_operations()
    return data_model
