from astroid.nodes import ExtSlice
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.slice import Slice


def parse_ext_slice(node: ExtSlice, container: Container) -> BaseNode:
    """Miniparser for Astroid's ExtSlice node.
	The extracted information are saved in the Slice node, which is recursively returned to the parent node.

	Deprecated from Astroid since v2.7.0

	:param node: Astroid node to be parsed
	:type node: ExtSlice
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Slice()
    data_model.initialization(container, node)

    parsed_interval = data_model.parse_node(node.dims[0])

    data_model.start = parsed_interval
    data_model.end = parsed_interval
    data_model.step = parsed_interval

    if len(node.dims) > 1:
        data_model.index = data_model.parse_node(node.dims[1])

    data_model.final_operations()
    return data_model
