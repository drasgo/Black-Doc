from astroid.nodes import YieldFrom

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.yield_statement import YieldStatement


def parse_yield_from(node: YieldFrom, container: Container) -> BaseNode:
    """Miniparser for Astroid's Yield From node.
	The extracted information are saved in the YieldStatement node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: YieldFrom
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = YieldStatement()
    data_model.initialization(container, node)

    data_model.from_flag = True
    data_model.value = data_model.parse_node(node.value)

    data_model.final_operations()
    return data_model
