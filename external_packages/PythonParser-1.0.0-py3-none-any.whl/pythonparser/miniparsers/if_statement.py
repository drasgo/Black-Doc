from astroid.nodes import If
from collections import Iterable

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.if_expr import IfExpr


def parse_if(node: If, container: Container) -> BaseNode:
    """Miniparser for Astroid's If Statement node.
    The extracted information are saved in the IfExpr node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: If
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = IfExpr()
    data_model.initialization(container, node)

    data_model.operation_as_string = node.as_string()
    data_model.test = data_model.parse_node(node.test)

    if isinstance(node.body, Iterable):
        for consequence in node.body:
            data_model.consequences.append(data_model.parse_node(consequence))

        for alternative in node.orelse:
            data_model.alternatives.append(data_model.parse_node(alternative))

    data_model.final_operations()
    return data_model
