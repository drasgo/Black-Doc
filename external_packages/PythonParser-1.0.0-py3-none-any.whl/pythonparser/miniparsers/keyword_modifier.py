from astroid.nodes import Keyword

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.keyword_argument import KeywordArgument


def parse_keyword(node: Keyword, container: Container) -> BaseNode:
    """Miniparser for Astroid's Keyword node.
    The extracted information are saved in the KeywordArgument node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Keyword
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = KeywordArgument()
    data_model.initialization(container, node)

    data_model.name = node.arg

    for child in node.get_children():
        data_model.value = data_model.parse_node(child)

    data_model.final_operations()
    return data_model
