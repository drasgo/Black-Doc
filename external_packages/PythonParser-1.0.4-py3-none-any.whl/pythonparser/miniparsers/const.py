from astroid.nodes import Const

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.constant import Constant

TYPES = {
    "str": "string",
    "int": "integer",
    "float": "float",
    "bool": "boolean",
    "NoneType": "none",
    "complex": "complex",
    "Ellipsis": "ellipsis",
    "bytes": "bytes",
}


def parse_const(node: Const, container: Container) -> BaseNode:
    """Miniparser for Astroid's Constant node.
    The extracted information are saved in the Constant node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Contst
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Constant()
    data_model.initialization(container, node)

    data_model.genus += TYPES[node.pytype().split(".")[-1]]
    data_model.value = str(node.value).translate(str.maketrans("", "", "'\""))

    data_model.final_operations()
    return data_model
