class ImportTree:
    def __init__(self, node_name):
        self._node_name = node_name
        self._path_list = self._node_name.split(".")
        self._imports_list = []
        self._parsed_path = {}
        self._dir_refs = 0
        self._imports_relative = self.has_relative_imports()
        self.compute_path()

    def as_dict(self):
        return {
            "relative_fs_import": self._imports_relative,
            "reverse_path_refs": self._dir_refs,
            "source_path": self._parsed_path,
        }

    def has_relative_imports(self):
        # non dots start at?
        non_dots_indices = [i for i, alpha in enumerate(self._path_list) if alpha != ""]
        first_non_dot = non_dots_indices[0]
        self._dir_refs = first_non_dot
        if first_non_dot == 0:
            self._imports_list = self._path_list
            return False
        else:
            self._dir_refs = first_non_dot
            self._imports_list = self._path_list[first_non_dot:]
            return True

    def compute_path(self):
        imports_len = len(self._imports_list)
        if imports_len == 1:
            name = self._imports_list[0]
            self._parsed_path[name] = {"name": name, "source": "PYTHONPATH"}
        else:
            for i, e in enumerate(self._imports_list[::-1]):
                last = i + 1 == imports_len
                if not last:
                    self._parsed_path[e] = {
                        "name": e,
                        "source": self._imports_list[i + 1],
                    }
                else:
                    self._parsed_path[e] = {"name": e, "source": "PYTHONPATH"}


if __name__ == "__main__":
    node_names = [".x.y.z", "..f.g.o", "a.b.c", "p", "p.q"]
    for node in node_names:
        tree = ImportTree(node)
        print(tree.as_dict())
