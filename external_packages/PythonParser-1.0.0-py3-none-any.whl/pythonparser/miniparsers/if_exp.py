from astroid.nodes import IfExp

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.if_expr import IfExpr


def parse_if_exp(node: IfExp, container: Container) -> BaseNode:
    """Miniparser for Astroid's If Expression node.
    The extracted information are saved in the IfExpr node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: IfExp
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = IfExpr()
    data_model.initialization(container, node)

    data_model.operation_as_string = node.as_string()
    data_model.test = data_model.parse_node(node.test)

    data_model.final_operations()
    return data_model
