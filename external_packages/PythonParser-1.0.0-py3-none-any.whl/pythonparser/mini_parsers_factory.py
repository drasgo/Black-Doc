from astroid.node_classes import NodeNG
import logging


LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG)


def get_mini_parser_by_node(node: NodeNG) -> callable:
    """
    Checks the type of the current astroid node, and returns the appropriate callable function parser. The chosen
    function is tailored implemented to extract information from the specific type of the Astroid node.
    For more information, check out the file pythonparser.lib.miniparsers.v0.parser_methods.

    :param node: Astroid node to be parsed
    :type node: NodeNG
    :returns: callable - miniparser function for the extracted type of the Astroid node
    """
    from pythonparser.miniparsers.parser_methods import parser_methods

    try:
        kind = type(node)
        mini_parser = parser_methods[kind]
        return mini_parser
    except Exception:
        from pythonparser.miniparsers.none_type import parse_none

        return parse_none
