from astroid.nodes import ClassDef, FunctionDef
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.class_def import Class


def parse_class(node: ClassDef, container: Container) -> BaseNode:
    """Miniparser for Astroid's ClassDef node.
    The extracted information are saved in the Class node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: ClassDef
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Class()
    data_model.initialization(container, node)
    data_model.name = node.name
    data_model.add_current_context(data_model.name)
    data_model.documentation = node.doc if node.doc else ""

    if node.decorators:
        data_model.decorators = data_model.parse_node(node.decorators)

    for inher in node.bases:
        data_model.inheritance.append(inher.as_string())

    for statement in node.body:
        parsed_statement = data_model.parse_node(statement)
        data_model.body.append(data_model.parse_node(statement))

        if isinstance(statement, FunctionDef):
            data_model.methods.append(parsed_statement.name)

    data_model.class_variables = data_model.container.get_current_class_attributes(
        data_model.name
    )
    data_model.object_variables = data_model.container.get_current_object_attributes(
        data_model.name
    )

    data_model.remove_current_context()
    data_model.final_operations()

    return data_model
