from astroid.nodes import While

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.while_loop import WhileLoop


def parse_while(node: While, container: Container) -> BaseNode:
    """Miniparser for Astroid's While node.
    The extracted information are saved in the WhileLoop node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: While
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = WhileLoop()
    data_model.initialization(container, node)

    data_model.test = data_model.parse_node(node.test)

    for consequence in node.body:
        data_model.consequences.append(data_model.parse_node(consequence))

    for alternative in node.orelse:
        data_model.alternatives.append(data_model.parse_node(alternative))

    data_model.final_operations()
    return data_model
