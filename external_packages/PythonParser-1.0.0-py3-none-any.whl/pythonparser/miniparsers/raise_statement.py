from astroid.nodes import Raise

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.raise_statement import RaiseStatement


def parse_raise(node: Raise, container: Container) -> BaseNode:
    """Miniparser for Astroid's Raise node.
    The extracted information are saved in the RaiseStatement node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Raise
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = RaiseStatement()
    data_model.initialization(container, node)

    data_model.cause = data_model.parse_node(node.cause)
    data_model.exception = data_model.parse_node(node.exc)

    data_model.final_operations()
    return data_model
