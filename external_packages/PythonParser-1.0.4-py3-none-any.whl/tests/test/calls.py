call1(var1)

call2(var1, var2, var3)

call3(var1, var2=var2)

call4(*[1, "var2", var3])

call5(**{"var1": 1, "var2": var2})

this.call6()

this.i_s.a().call7(var1, var2=var2)
