import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.continue_statement import Continue


def parse_continue(node: astroid.nodes.Continue, container: Container) -> BaseNode:
    """Miniparser for Astroid's Continue node.
    The extracted information are saved in the Continue node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.Continue
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Continue()
    data_model.initialization(container, node)

    data_model.final_operations()
    return data_model
