import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.with_key import With, WithElement


def parse_with(node: astroid.nodes.With, container: Container) -> BaseNode:
    """Miniparser for Astroid's With node.
	The extracted information are saved in the With node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: astroid.nodes.With
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = With()
    data_model.initialization(container, node)

    for body in node.body:
        data_model.body.append(data_model.parse_node(body))

    for elem in node.items:
        element_model = WithElement(
            element=data_model.parse_node(elem[0]), alias=data_model.parse_node(elem[1])
        )
        data_model.elements.append(element_model)

    data_model.final_operations()
    return data_model
