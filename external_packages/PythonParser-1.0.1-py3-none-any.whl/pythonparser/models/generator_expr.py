from dataclasses import field, dataclass


from typing import List

from pythonparser.models.baseNode import BaseNode

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class GeneratorExpr(BaseNode):
    genus: str = "generator_expression"
    element_categories: List[str] = field(default_factory=lambda: ["expression"])
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["yield", "generate"]
    )
    node_as_string: str = ""
    kind: str = ""
    cognitive_cost: int = 2

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = "expression generator"
        return humanized
