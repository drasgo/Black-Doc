import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container


def parse_async_for(node: astroid.nodes.AsyncFor, container: Container) -> BaseNode:
    """Miniparser for Astroid's AsyncFor node.
	The extracted information are saved in the BaseNode node, which is recursively returned to the parent node.

	TODO

	:param node: Astroid node to be parsed
	:type node: AsyncFor
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = BaseNode()
    data_model.initialization(container, node)

    data_model.final_operations()
    return data_model
