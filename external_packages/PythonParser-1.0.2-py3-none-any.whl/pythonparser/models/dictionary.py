from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from dataclasses_json import dataclass_json
from pythonparser.container import Container


@dataclass_json
@dataclass
class DictPair:
    key: Container.every_node = None
    value: Container.every_node = None

    def __init__(self, key, value):
        self.key = key
        self.value = value


@dataclass_json
@dataclass
class DictContainer(BaseNode):
    genus: str = "dictionary"
    element_categories: List[str] = field(
        default_factory=lambda: ["values_container", "data_structure"]
    )
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["key_indexed_container"]
    )
    items: List[DictPair] = field(default_factory=list)
    node_as_string: str = ""

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        if self.items:
            humanized = f"dictionary with {str(len(self.items))} pair(s) ('{self.node.as_string()}')"

        else:
            humanized = "empty dictionary"

        return humanized
