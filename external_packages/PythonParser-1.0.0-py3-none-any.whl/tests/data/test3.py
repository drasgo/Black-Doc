from x.y import Z


def assign_simple():
    for x in (1, 2, 3):
        print(x)
        print(y)
    yield x
