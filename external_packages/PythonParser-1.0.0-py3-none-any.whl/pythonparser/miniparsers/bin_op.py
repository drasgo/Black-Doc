from astroid.nodes import BinOp
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.binary_op import BinaryOperation


def parse_bin_op(node: BinOp, container: Container) -> BaseNode:
    """Miniparser for Astroid's BinOp node.
    The extracted information are saved in the BinaryOperation node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: BinOp
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = BinaryOperation()
    data_model.initialization(container, node)

    data_model.op = node.op
    data_model.operation_as_string = node.as_string()

    data_model.left_hand = data_model.parse_node(node.left)
    data_model.right_hand = data_model.parse_node(node.right)

    data_model.final_operations()
    return data_model
