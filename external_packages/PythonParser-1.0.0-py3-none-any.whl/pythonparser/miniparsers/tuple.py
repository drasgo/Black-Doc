from astroid.nodes import Tuple

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.tuple import TupleContainer


def parse_tuple(node: Tuple, container: Container) -> BaseNode:
    """Miniparser for Astroid's Tuple node.
    The extracted information are saved in the TupleStatement node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Tuple
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = TupleContainer()
    data_model.initialization(container, node)

    data_model.arity = len(node.elts)
    for child in node.elts:
        data_model.elements.append(data_model.parse_node(child))

    data_model.final_operations()
    return data_model
