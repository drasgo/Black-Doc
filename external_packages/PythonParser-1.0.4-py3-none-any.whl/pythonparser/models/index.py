from dataclasses import field, dataclass

from typing import List

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Index(BaseNode):
    genus: str = "index"
    element_categories: List[str] = field(
        default_factory=lambda: ["values_container_position", "index_lookup"]
    )
    name: str = str()
    value: Container.every_node = None

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"index {self.value.get_description}"
        return humanized
