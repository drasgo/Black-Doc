from astroid.nodes import AssignAttr

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.attribute import AttributeName


def parse_assignment_attribute(node: AssignAttr, container: Container) -> BaseNode:
    """Miniparser for Astroid's Assign Attribute node.
    The extracted information are saved in the AttributeName node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: AssignAttr
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = AttributeName()
    data_model.initialization(container, node)

    data_model.node_string = node.as_string()
    data_model.name = node.as_string().split(".")[-1]
    data_model.source_path = node.as_string().split(".")[:-1]
    data_model.source_path = data_model.source_path[::-1]

    data_model.final_operations()
    return data_model
