from astroid.nodes import TryFinally

from pythonparser.models.baseNode import BaseNode
from pythonparser.miniparsers.try_except import try_except_model
from pythonparser.container import Container
from pythonparser.models.try_except import TryExcept


def parse_try_finally(node: TryFinally, container: Container) -> BaseNode:
    """Miniparser for Astroid's Try-Except-Finally node.
	The extracted information are saved in the TryExcept node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: TryFinally
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    if node.body and isinstance(node.body[0], TryExcept):
        data_model = try_except_model(node.body[0], container)

    else:
        data_model = TryExcept()
        data_model.initialization(container, node)

        for body in node.body:
            data_model.try_block.append(data_model.parse_node(body))

    for final in node.finalbody:
        data_model.final_body.append(data_model.parse_node(final))

    data_model.final_operations()
    return data_model
