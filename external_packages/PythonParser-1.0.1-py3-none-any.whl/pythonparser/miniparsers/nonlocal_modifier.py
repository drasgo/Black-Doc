from astroid.nodes import Nonlocal

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.nonlocal_mod import NonLocal


def parse_nonlocal(node: Nonlocal, container: Container) -> BaseNode:
    """Miniparser for Astroid's Non Local node.
	The extracted information are saved in the NonLocal node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: Nonlocal
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = NonLocal()
    data_model.initialization(container, node)

    data_model.names = node.names

    data_model.final_operations()
    return data_model
