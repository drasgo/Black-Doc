from setuptools import setup, find_packages

setup(
    name="pythonparser",
    version="0.0.1",
    author="Heuro Labs Team",
    author_email="heuro@git.tours",
    url="git.tours/pythonparser",
    description="A high level, semantics oriented python code parser",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Proprietary",
        "Operating System :: Linux",
    ],
)
