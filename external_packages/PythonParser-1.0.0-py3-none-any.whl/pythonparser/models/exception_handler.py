from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class ExceptionHandler(BaseNode):
    name: str = str()
    alias: str = str()
    genus: str = "exception_handler"
    element_categories: List[str] = field(default_factory=lambda: ["flow_control"])
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["flow_control", "error_handling"]
    )
    statements: List[Container.every_node] = field(default_factory=list)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"The handled exceptions are {self.name}"

        if self.alias:
            humanized += f" with alias {self.alias}."

        else:
            humanized += "."

        if self.statements:
            humanized += " In the body of this exception handler, the following statements are executed: "
            for state in self.statements:

                if state is None:
                    state = "pass"

                elif "description" in state.__annotations__ and state.get_description:
                    state = state.get_description

                else:
                    state = ""
                state_description = "pass" if not state else state.get_description
                humanized += state_description + "; "

            if humanized[-2] == ";":
                humanized = humanized[:-2] + "."

        return humanized
