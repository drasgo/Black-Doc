from astroid.nodes import ListComp

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.list_comprehension import ListComprehension


def parse_list_comprehension(node: ListComp, container: Container) -> BaseNode:
    """Miniparser for Astroid's List Comprehension node.
	The extracted information are saved in the ListComprehension node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: ListComp
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = ListComprehension()
    data_model.initialization(container, node)

    data_model.node_as_string = node.as_string()

    data_model.final_operations()
    return data_model
