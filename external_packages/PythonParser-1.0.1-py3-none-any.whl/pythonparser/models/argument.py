from dataclasses import field, dataclass

from typing import List

from pythonparser.models.baseNode import BaseNode
from dataclasses_json import dataclass_json

TYPES = {
    "str": "string",
    "int": "integer",
    "float": "float",
    "bool": "boolean",
    "NoneType": "none",
    "complex": "complex",
    "Ellipsis": "ellipsis",
    "bytes": "bytes",
    "dict": "dictionary",
    "list": "list",
    "tuple": "tuple",
}


@dataclass_json
@dataclass
class Argument(BaseNode):
    name: str = ""
    param_type_hint: str = ""
    value: str = str()
    is_vararg: bool = False
    is_kwarg: bool = False

    genus: str = "argument"
    element_categories: List[str] = field(
        default_factory=lambda: ["storage", "value_pass"]
    )

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = ""
        if self.param_type_hint:
            humanized += f"{TYPES.get(self.param_type_hint, self.param_type_hint)} "
        humanized += f"argument @{self.name}@"

        if self.value:
            humanized += f" with default value {self.value}"

        return humanized
