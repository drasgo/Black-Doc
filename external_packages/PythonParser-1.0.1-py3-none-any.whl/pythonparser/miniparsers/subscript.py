import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.subscript import Subscript


def parse_subscript(node: astroid.nodes.Subscript, container: Container) -> BaseNode:
    """Miniparser for Astroid's Subscript node.
    The extracted information are saved in the Subscript node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.Subscript
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Subscript()
    data_model.initialization(container, node)

    data_model.name = node.as_string()

    data_model.partition = data_model.parse_node(node.slice)
    data_model.value_contained = data_model.parse_node(node.value)

    data_model.final_operations()
    return data_model
