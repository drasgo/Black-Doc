from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Class(BaseNode):
    name: str = ""
    documentation: str = ""
    inheritance: List[str] = field(default_factory=list)
    decorators: Container.every_node = None
    body: List[Container.every_node] = field(default_factory=list)
    class_variables: List[Container.every_node] = field(default_factory=list)
    object_variables: List[Container.every_node] = field(default_factory=list)
    methods: List[str] = field(default_factory=list)

    genus: str = "class"
    element_categories: List[str] = field(
        default_factory=lambda: ["context_manager", 'class", "structural", "functional']
    )

    def additional_final_operations(self):
        """Perform few final operations before leaving the current node. Add the class node to the container."""
        self.container.add_class(self)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"Class ^^{self.name}^^. "

        if self.decorators:
            humanized += f"It has the following {self.decorators.get_description}. "

        if self.inheritance:
            humanized += f"It inherits from {', '.join(self.inheritance)}. "

        if self.class_variables:
            humanized += "The class variables are:"
            for cls_attr in self.class_variables:
                humanized += (
                    f" {cls_attr.get('description', cls_attr.get('label', ''))},"
                )
            humanized = humanized[:-1] + ". "

        if self.object_variables:
            humanized += "The object attributes are:"
            for obj_attr in self.object_variables:
                humanized += (
                    f" {obj_attr.get('description', obj_attr.get('label', ''))},"
                )
            humanized = humanized[:-1] + ". "

        if self.methods:
            humanized += f"The class methods are: $${'$$, $$'.join(self.methods)}$$. "

        humanized += "The statements executed in the class' body are: "

        for state in self.body:
            humanized += "\n\t- " + state.get_description
            humanized = humanized.strip(".").strip("\n") + ";"

        humanized = (humanized[:-1] if humanized[-2] != "." else humanized[:-2]) + "."
        return humanized
