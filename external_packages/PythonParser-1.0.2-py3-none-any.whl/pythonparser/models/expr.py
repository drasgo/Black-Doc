from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container


@dataclass
class Expr(BaseNode):
    genus: str = "expression"
    element_categores: List[str] = field(default_factory=lambda: ["values_generation"])
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["value", "computation"]
    )
    kind: str = ""
    value: Container.every_node = None
    cognitive_cost: int = 2

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"{self.value.get_description.replace('return value', 'execution')}"
        return humanized
