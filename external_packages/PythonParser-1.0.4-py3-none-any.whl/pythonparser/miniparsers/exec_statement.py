import astroid
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.execute import Execute


def parse_exec(node: astroid.nodes.Exec, container: Container) -> BaseNode:
    """Miniparser for Astroid's Exec node.
	The extracted information are saved in the Execute node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: astroid.nodes.Exec
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Execute()
    data_model.initialization(container, node)

    data_model.value = data_model.parse_node(node.expr)

    data_model.final_operations()
    return data_model
