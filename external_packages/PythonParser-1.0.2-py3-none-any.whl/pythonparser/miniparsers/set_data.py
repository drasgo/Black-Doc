from astroid.nodes import Set

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.set import SetContainer


def parse_set(node: Set, container: Container) -> BaseNode:
    """Miniparser for Astroid's Set node.
    The extracted information are saved in the SetContainer node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Set
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = SetContainer()
    data_model.initialization(container, node)

    for child in node.get_children():
        data_model.elements.append(data_model.parse_node(child))

    data_model.final_operations()
    return data_model
