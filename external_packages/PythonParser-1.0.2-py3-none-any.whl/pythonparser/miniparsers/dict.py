from astroid.nodes import Dict
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.dictionary import DictContainer, DictPair


def parse_dict(node: Dict, container: Container) -> BaseNode:
    """Miniparser for Astroid's Dict nodes.
    The extracted information are saved in the DictContainer node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Dict
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = DictContainer()
    data_model.initialization(container, node)

    for item in node.items:
        (key_node, value_node) = item
        data_model.items.append(
            DictPair(
                key=data_model.parse_node(key_node),
                value=data_model.parse_node(value_node),
            )
        )

    data_model.final_operations()
    return data_model
