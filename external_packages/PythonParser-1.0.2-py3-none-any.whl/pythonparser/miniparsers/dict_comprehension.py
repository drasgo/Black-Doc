from astroid.nodes import DictComp

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.dict_comprehension import DictComprehension


def parse_dict_comprehension(node: DictComp, container: Container) -> BaseNode:
    """Miniparser for Astroid's Dictionary Comprehension nodes.
	The extracted information are saved in the DictComprehension node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: DictComp
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = DictComprehension()
    data_model.initialization(container, node)

    data_model.node_as_string = node.as_string()

    data_model.final_operations()
    return data_model
