from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Delete(BaseNode):
    targets: List[Container.every_node] = field(default_factory=list)
    genus: str = "delete"
    element_categories: List[str] = field(
        default_factory=lambda: ["functional", "delete_element"]
    )

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = ""
        for target in self.targets:
            humanized += '"' + target.description + '", '
        humanized = humanized[:-2] + " deleted."

        return humanized
