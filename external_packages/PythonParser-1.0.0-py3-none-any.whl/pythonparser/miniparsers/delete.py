import astroid
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.delete import Delete


def parse_delete(node: astroid.nodes.Delete, container: Container) -> BaseNode:
    """Miniparser for Astroid's Delete nodes.
	The extracted information are saved in the Delete node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: astroid.nodes.Delete
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Delete()
    data_model.initialization(container, node)

    for target in node.targets:
        data_model.targets.append(data_model.parse_node(target))

    data_model.final_operations()
    return data_model
