from astroid.nodes import DelName

from pythonparser.models.baseNode import BaseNode
from pythonparser.miniparsers.name import parse_name
from pythonparser.container import Container


def parse_del_name(node: DelName, container: Container) -> BaseNode:
    """Miniparser for Astroid's DelName node.
    The extracted information are saved in the Name node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: DelName
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    return parse_name(node, container)
