from astroid.nodes import BoolOp
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.bool_op import BooleanOperation


def parse_bool_op(node: BoolOp, container: Container) -> BaseNode:
    """Miniparser for Astroid's BoolOp node.
    The extracted information are saved in the BooleanOperation node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: BoolOp
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = BooleanOperation()
    data_model.initialization(container, node)

    data_model.op = node.op
    for child in node.values:
        data_model.operands.append(data_model.parse_node(child))

    data_model.final_operations()
    return data_model
