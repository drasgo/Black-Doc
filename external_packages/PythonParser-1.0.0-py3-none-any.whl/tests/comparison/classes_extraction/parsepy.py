import libcst as cst
import sys
from pythonparser.lib.functions.function import compute_context


class Parser:
    """
    Parse python source code.
    """

    def __init__(self, code: str):
        self.concrete_tree = cst.parse_module(code)
        self.concrete_tree_parser = self.ConcreteParser()

    def parse(self):
        self.concrete_tree.visit(self.concrete_tree_parser)

    @property
    def classes(self) -> list:
        """
        Returns a list of strings for all classes found for the parsed code.
        """
        if len(self.concrete_tree_parser._classes.keys()) > 0:
            classes_names = [n for n in self.concrete_tree_parser._classes.keys()]
            return classes_names
        return []

    def doc_strings(self, class_name: str) -> str:
        """
        Returns the doc string for class class_name as a string.
        """
        try:
            doc_string = self.concrete_tree_parser._classes.get(class_name).get(
                "documentation"
            )
            return doc_string
        except:
            return ""
        pass

    def methods(self, class_name: str) -> list:
        """
        Returns class methods for class class_name as a list of of hashes of method descriptions
        """
        if class_name in self.concrete_tree_parser._classes.keys():
            methods_names = [
                n
                for n in self.concrete_tree_parser._classes.get(class_name).get(
                    "methods"
                )
            ]
            return methods_names
        else:
            raise ValueError("Class doesn not exist")

    def imports(self) -> list:
        """
        Returns imported modules found in the code
        """
        return self.concrete_tree_parser._imports

    def functions(self):
        """
        Returns all functions, including classes methods in the parsed code
        """
        return self.concrete_tree_parser._functions

    def print(self):
        for item in self.concrete_tree_parser._stack:
            print(item)

    class ConcreteParser(cst.CSTVisitor):
        def __init__(self):
            self._stack = []
            self._context = [{"type": "global", "module": "main"}]
            self._classes = {}
            self._functions = [{}]
            self._imports = [{}]

        def visit_Import(self, node: cst.Import):
            import_hash = {}
            for name in node.names:
                import_hash["name"] = name.name.value
                import_hash["is_subset"] = False
                import_hash["context"] = self._context[-1]
            self._imports.append(import_hash)

        def visit_ImportFrom(self, node: cst.ImportFrom):
            import_hash = {}
            for name in node.names:
                import_hash["name"] = name.name.value
                import_hash["is_subset"] = True
                module_path = node.module.value.value.value
                submodule_path = node.module.value.attr.value
                full_path = [module_path, submodule_path]
                import_hash["source"] = full_path
                import_hash["context"] = self._context[-1]
            self._imports.append(import_hash)

        def visit_ClassDef(self, node: cst.ClassDef):
            """
            Triggered when processing source code and a class ... is encountered
            """
            name = node.name.value
            self._classes[name] = {}
            methods = []
            inner_methods = []
            self._classes[name]["methods"] = methods
            self._classes[name]["inner_methods"] = inner_methods
            self._classes[name]["documentation"] = node.get_docstring()
            self._context.append({"type": "class", "name": name})
            self._stack.append(({"type": "class", "name": name}))

        def leave_ClassDef(self, node: cst.ClassDef):
            if len(self._context) >= 2:
                self._context.pop()

        def visit_FunctionDef(self, node: cst.FunctionDef):
            """
            Triggered when a function definition is encountered
            """
            name = node.name.value
            func_hash = {}
            func_hash["name"] = name
            func_hash["documentation"] = node.get_docstring()
            func_hash["parameters"] = []
            current_context = self._context[-1]
            for param in node.params.children:
                param_name = param.name.value
                func_hash["parameters"].append(param_name)
            (kind, scope) = compute_context(current_context)
            func_hash["type"] = kind
            func_hash["scope"] = scope
            if func_hash == {}:
                return
            self._context.append(func_hash)
            self._stack.append((func_hash))
            self._functions.append(func_hash)

        def leave_FunctionDef(self, node: cst.FunctionDef):
            if len(self._context) >= 2:
                self._context.pop()

        def visit_Arg(self, node: cst.Arg):
            """
            Triggered when visiting an argument node
            """
            self._stack.append(
                ({"type": "argument", "scope": self._context[-1], "name": node.value})
            )


if __name__ == "__main__":
    code = open(sys.argv[1]).read()
    parser = Parser(code)
    parser.parse()
    classes = parser.classes
    if len(sys.argv) > 2:
        print(parser.methods(sys.argv[2]))
    else:
        for cls in classes:
            print(f"Processing {cls}")
            print(parser.methods(cls))
            print(parser.doc_strings(cls))
        print(parser.functions())
    imports = parser.imports()
    for import_hash in imports:
        print(import_hash)
