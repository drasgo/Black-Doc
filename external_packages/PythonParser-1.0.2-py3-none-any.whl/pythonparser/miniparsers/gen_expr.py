import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.generator_expr import GeneratorExpr


def parse_generator_expr(
    node: astroid.nodes.GeneratorExp, container: Container
) -> BaseNode:
    """Miniparser for Astroid's Generator of Expression node.
    The extracted information are saved in the GeneratorExpr node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.GeneratorExpr
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = GeneratorExpr()
    data_model.initialization(container, node)

    data_model.node_as_string = node.as_string()

    data_model.final_operations()
    return data_model
