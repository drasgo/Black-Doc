from typing import Union

from pythonparser.models.with_key import With
from pythonparser.models.while_loop import WhileLoop
from pythonparser.models.unknown import Unknown
from pythonparser.models.unary_op import UnaryOperation
from pythonparser.models.tuple import TupleContainer
from pythonparser.models.try_except import TryExcept
from pythonparser.models.subscript import Subscript
from pythonparser.models.starred import Starred
from pythonparser.models.slice import Slice
from pythonparser.models.set import SetContainer
from pythonparser.models.return_statement import ReturnStatement
from pythonparser.models.raise_statement import RaiseStatement
from pythonparser.models.pass_statement import Pass
from pythonparser.models.nonlocal_mod import NonLocal
from pythonparser.models.none_type import NoneType
from pythonparser.models.name import Name
from pythonparser.models.method import Method
from pythonparser.models.list_comprehension import ListComprehension
from pythonparser.models.list import ListContainer
from pythonparser.models.keyword_argument import KeywordArgument
from pythonparser.models.joined_string import JoinedString
from pythonparser.models.index import Index
from pythonparser.models.import_op import Import
from pythonparser.models.if_expr import IfExpr
from pythonparser.models.global_mod import Global
from pythonparser.models.generator_expr import GeneratorExpr
from pythonparser.models.formatted_val import FormattedValue
from pythonparser.models.for_loop import ForLoop
from pythonparser.models.expr import Expr
from pythonparser.models.execute import Execute
from pythonparser.models.exception_handler import ExceptionHandler
from pythonparser.models.empty import Empty
from pythonparser.models.dictionary import DictContainer
from pythonparser.models.dict_unpack import DictUnpack
from pythonparser.models.dict_comprehension import DictComprehension
from pythonparser.models.delete import Delete
from pythonparser.models.decorator import Decorator
from pythonparser.models.continue_statement import Continue
from pythonparser.models.constant import Constant
from pythonparser.models.comparison import Comparison
from pythonparser.models.class_def import Class
from pythonparser.models.call import Call
from pythonparser.models.break_statement import Break
from pythonparser.models.bool_op import BooleanOperation
from pythonparser.models.binary_op import BinaryOperation
from pythonparser.models.attribute import AttributeName
from pythonparser.models.assignment import Assignment
from pythonparser.models.assert_statement import AssertStatement
from pythonparser.models.arguments import Arguments
from pythonparser.models.argument import Argument
from pythonparser.models.baseNode import BaseNode
from pythonparser.models.yield_statement import YieldStatement

EVERY_NODE = Union[
    Argument,
    Arguments,
    AssertStatement,
    Assignment,
    AttributeName,
    BinaryOperation,
    BooleanOperation,
    Break,
    Call,
    Class,
    Comparison,
    Constant,
    Constant,
    Constant,
    Constant,
    Constant,
    Constant,
    Constant,
    Constant,
    Continue,
    Decorator,
    Delete,
    DictComprehension,
    DictUnpack,
    DictContainer,
    Empty,
    ExceptionHandler,
    Execute,
    Expr,
    ForLoop,
    FormattedValue,
    GeneratorExpr,
    Global,
    IfExpr,
    Import,
    Index,
    JoinedString,
    KeywordArgument,
    ListContainer,
    ListComprehension,
    Method,
    Method,
    Name,
    NoneType,
    NonLocal,
    Pass,
    RaiseStatement,
    ReturnStatement,
    SetContainer,
    Slice,
    Starred,
    Subscript,
    TryExcept,
    TupleContainer,
    UnaryOperation,
    Unknown,
    WhileLoop,
    With,
    YieldStatement,
    None,
]

genus2nodes = {
    "argument": Argument,
    "call_arguments": Arguments,
    "assert_statement": AssertStatement,
    "value_assignment": Assignment,
    "attribute": AttributeName,
    "binary_operation": BinaryOperation,
    "boolean_operation": BooleanOperation,
    "break_statement": Break,
    "call_statement": Call,
    "class": Class,
    "comparison": Comparison,
    "constant_string": Constant,
    "constant_integer": Constant,
    "constant_float": Constant,
    "constant_boolean": Constant,
    "constant_none": Constant,
    "constant_complex": Constant,
    "constant_ellipsis": Constant,
    "constant_bytes": Constant,
    "continue_statement": Continue,
    "decorator": Decorator,
    "delete": Delete,
    "dict_comprehension": DictComprehension,
    "dict_unpack": DictUnpack,
    "dictionary": DictContainer,
    "empty_node": Empty,
    "exception_handler": ExceptionHandler,
    "statement_execution": Execute,
    "expression": Expr,
    "for_loop": ForLoop,
    "formatted_value": FormattedValue,
    "generator_expression": GeneratorExpr,
    "global_modifier": Global,
    "If_Expression": IfExpr,
    "import": Import,
    "index": Index,
    "joined_string": JoinedString,
    "keyword": KeywordArgument,
    "list": ListContainer,
    "list_comprehension": ListComprehension,
    "function": Method,
    "class_method": Method,
    "variable": Name,
    "none_type": NoneType,
    "nonlocal_modifier": NonLocal,
    "pass_statement": Pass,
    "raise_statement": RaiseStatement,
    "return": ReturnStatement,
    "set": SetContainer,
    "slice": Slice,
    "starred_attribute": Starred,
    "subscript": Subscript,
    "try_except": TryExcept,
    "tuple": TupleContainer,
    "unary_op": UnaryOperation,
    "unknown": Unknown,
    "while_loop": WhileLoop,
    "with_manager": With,
    "yield_statement": YieldStatement,
}


def get_datamodel(genus: str):
    return genus2nodes.get(genus, BaseNode)


def assert_genus_correctness():
    for genus in genus2nodes:
        if not genus.startswith("constant_") and genus != "class_method":
            try:
                assert genus == get_datamodel(genus).genus
            except AssertionError:
                print(genus)


if __name__ == "__main__":
    # assert_genus_correctness()
    # for elemen in genus2nodes:
    print([genus2nodes[elem].__name__ for elem in genus2nodes])
