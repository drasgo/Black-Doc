from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class WhileLoop(BaseNode):
    genus: str = "while_loop"
    element_categories: List[str] = field(default_factory=lambda: ["flow_control"])
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["conditional_statement", "branching"]
    )
    test: Container.every_node = None
    consequences: List[Container.every_node] = field(default_factory=list)
    alternatives: List[Container.every_node] = field(default_factory=list)
    kind: str = None
    cognitive_cost: int = 2

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = (
            f"::while:: construct with as condition the {self.test.get_description}."
        )

        if self.consequences:
            if len(self.consequences) == 1 and self.consequences[0] is None:
                humanized += " In the ::while:: body nothing is executed."

            else:
                humanized += (
                    " In the ::while:: body, the following statements are executed:"
                )

                for body in self.consequences:
                    if body.genus in ("class", "function", "class_method"):
                        corrected_body = f"{body.get_description[:body.get_description.find('has')]}is defined"

                    else:
                        corrected_body = body.get_description.replace("\t", "\t\t")

                    corrected_body = corrected_body.strip(".").strip("")
                    humanized += f"\n\t- {corrected_body};"

                humanized = f"{humanized.strip(';')}."
        return humanized
