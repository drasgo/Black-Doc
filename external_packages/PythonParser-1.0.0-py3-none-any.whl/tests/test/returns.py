def return1():
    return function_reference


def return2():
    return 1 + 2


def return3():
    test = "test"
    return test


def return4():
    return "constant"


def return5():
    return simple_call()


def return6():
    return this.i_s.a().complex.call()


def return7():
    return "True" if call() else "False"


def return8():
    return {"key": "value"}


def return9():
    return ["test", "test"]


def return10():
    return "element1", "element2"
