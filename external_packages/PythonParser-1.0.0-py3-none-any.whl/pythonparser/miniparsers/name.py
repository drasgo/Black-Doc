from typing import Union
from astroid.nodes import Name, AssignName, DelName

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.name import Name


def parse_name(
    node: Union[Name, AssignName, DelName], container: Container
) -> BaseNode:
    """Miniparser for Astroid's Name, AssignName, and DelName nodes.
    The extracted information are saved in the Name node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Union[Name, AssignName, DelName]
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Name()
    data_model.initialization(container, node)

    data_model.name = str(node.name)

    data_model.final_operations()
    return data_model
