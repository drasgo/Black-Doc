import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.return_statement import ReturnStatement


RETURN_TYPE = {
    "str": "string_return",
    "int": "integer_return",
    "float": "float_return",
    "bool": "boolean_return",
    "NoneType": "none_return",
    "complex": "complex_value_return",
    "Ellipsis": "ellipsis_return",
    "bytes": "bytes_return",
    astroid.nodes.Tuple: "tuple_return",
    astroid.nodes.Call: "call_return",
    astroid.nodes.Expr: "call_return",
    astroid.nodes.Attribute: "variable/reference_return",
    astroid.nodes.Dict: "dict_return",
    astroid.nodes.DictUnpack: "dict_return",
    astroid.nodes.DictComp: "dict_return",
    astroid.nodes.List: "list_return",
    astroid.nodes.ListComp: "list_return",
}


def parse_return(node: astroid.nodes.Return, container: Container) -> BaseNode:
    """Miniparser for Astroid's Return node.
    The extracted information are saved in the ReturnStatement node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.Return
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = ReturnStatement()
    data_model.initialization(container, node)

    data_model.return_as_string = node.value.as_string() if node.value else ""
    data_model.return_value = data_model.parse_node(node.value)

    value = node.value.__class__
    if value is astroid.nodes.Const:
        value = RETURN_TYPE[node.value.pytype().split(".")[-1]]
    data_model.return_type = RETURN_TYPE.get(value, "complex_return")

    data_model.final_operations()
    return data_model
