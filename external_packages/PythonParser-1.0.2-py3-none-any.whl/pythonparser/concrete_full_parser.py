import logging
from typing import List

import astroid
from astroid.node_classes import NodeNG

from pythonparser.mini_parsers_factory import get_mini_parser_by_node
from pythonparser.container import Container
from pythonparser.models.parser_nodes import EVERY_NODE


LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG)


class PythonConcreteFullParser:
    """Class that actually performs the parsing of the Python code"""

    def __init__(self):
        super().__init__()
        self.container = Container()
        Container.every_node = EVERY_NODE
        self._stack = list()
        self.cached_stack = list()
        self.exceptions = []
        self.total_lines = 0

    def reset(self, code: str, description_enabled: bool):
        """Reset BaseMiniParser class variables

        :param code: Python code to be parsed
        :type code: str
        :param description_enabled: flag for defining if the description needs to be generated or not
        :type description_enabled: bool
        """
        self.container.reset(code, description_enabled)

    def get_stack(self) -> List[dict]:
        """ When the code is parsed, returns the parsed AST.

        :returns: List[dict] - collection of all the global scope nodes as dictionaries
        """
        if not self.cached_stack:
            for element in self._stack:
                converted_element = element.to_dict()
                self.cached_stack.append(converted_element)
        return self.cached_stack

    def get_general_info(self) -> dict:
        """ After having parsed the code, here some general information (such as the total number of lines)
        of the Python code are retrieved.

        :returns: dict - hash containing some general information of the Python code
        """
        return {"total_lines": self.total_lines}

    def get_descriptions(self) -> dict:
        """ After having parsed the code, here the generated description is returned, if its generation was enabled.

        :returns: dict - contains the generated description, or an empty dictionary if it was not generated
        """
        return self.container.get_descriptions()

    def get_calls_summary(self) -> List[dict]:
        """  After having parsed the code, here all the calls (in their "simplified" version) in the Python
         code can be retrieved.

        :returns: List[dict] - collection of all the calls (in their simplified version) as dictionaries in the Python code
        """
        return self.container.get_calls()

    def get_total_calls_summary(self) -> List[dict]:
        """  After having parsed the code, here all the calls in the Python code can be retrieved.

        :return: List[dict] - collection of all the calls as dictionaries in the Python code
        """
        return self.container.get_total_calls()

    def get_returns_summary(self) -> List[dict]:
        """  After having parsed the code, here all the returns (in their simplified version) in the Python
        code can be retrieved.

        :returns: List[dict] - collection of all the returns (in their simplified version) as dictionaries in the Python code
        """
        return self.container.get_returns()

    def get_total_returns_summary(self) -> List[dict]:
        """  After having parsed the code, here all the returns in the Python code can be retrieved.

        :returns: List[dict] - collection of all the returns as dictionaries in the Python code
        """
        return self.container.get_total_returns()

    def get_classes_summary(self) -> List[dict]:
        """  After having parsed the code, here all the classes in the Python code can be retrieved.

        :returns: List[dict] - collection of all the classes as dictionaries found in the Python code
        """
        return self.container.get_classes()

    def get_exceptions_summary(self) -> List[dict]:
        return self.container.get_exceptions()

    def get_class_methods_summary(self, class_name: str) -> List[dict]:
        """  After having parsed the code, here all the class methods for class class_name.

        :param class_name: name of the class we want to retrieve the methods from
        :type class_name: str
        :returns: List[dict] - collection of dictionaries containing information of one method each. The list will be
        empty if the class does not exist
        """
        for cls in self.get_classes_summary():
            if cls["name"] == class_name:
                return cls["methods"]
        return []

    def get_class_documentation(self, class_name: str) -> str:
        """  After having parsed the code, here the docstring for class class_name (if existing) is
        retrieved. If the class does not exist, an empty string is returned.

        :param class_name: name of the class we want to retrieve the docstring from
        :type class_name: str
        :returns: str - docstring of the class class_name, or an empty string if the class does not exist
        """
        for parsed_cls in self.get_classes_summary():
            if class_name == parsed_cls["name"]:
                return parsed_cls["documentation"]
        return ""

    def get_class_number_of_lines(self, class_name: str) -> int:
        """  After having parsed the code, here the number of lines of the class class_name, including
        docstrings, is retrieved. It is returned -1 if the class does not exist

        :param class_name: name of the class we want to retrieve the number of lines
        :type class_name: str
        :returns: int - number of lines for class class_name, or -1 if it does not exist
        """
        for parsed_cls in self.get_classes_summary():
            if class_name == parsed_cls["name"]:
                return parsed_cls["total_lines"]
        return -1

    def get_functions_summary(self) -> List[dict]:
        """  After having parsed the code, here all the functions (not in classes) in the
        Python code are retrieved.

        :returns: List[dict] - collection of all the functions as dictionaries in the Python code
        """
        return self.container.get_methods()

    def get_functions_code(self) -> List[dict]:
        """  After having parsed the code, here the code of all the functions in the Python code are
        retrieved.

        :returns: List[dict] - collection of the code of the functions in the Python code
        """
        return self.container.get_methods_code()

    def get_imports_summary(self) -> List[dict]:
        """  After having parsed the code, here all the imports of the Python code are retrieved.

        :returns: List[dict] - collection of the imports as dictionaries in the Python code
        """
        return self.container.get_imports()

    def get_assignments_summary(self) -> List[dict]:
        """  After having parsed the code, here all the assignments in the Python code can be retrieved.

        :returns: List[dict] - collection of all the assignments as dictionaries in the Python code
        """
        return self.container.get_assignments()

    def get_parsed_node(self, node: NodeNG) -> dict:
        """This function is called for each node of the global scope. It looks up the type of the node
        and chooses a miniparser to parse it with. Then, the chosen miniparser will parse it accordingly. This is the
        starting point of the recursive node lookup, parsing and saving. Finally, the parsed global node is returned to
        the caller. If there is any exception occured while recursively parsing the given node, the exception is
        saved in the final parsing status report.

        :param node: global scope node that is going to be parsed.
        :type node: NodeNG
        :returns: dict - dictionary containing the parsed node, or an empty dictionary if any problem occured while parsing it
        """
        # try:
        parser = get_mini_parser_by_node(node)
        return parser(node, self.container)
        # except Exception as exc:
        #     self.exceptions.append(str(exc))
        #     return {}

    def parse(self, code: str, description_enabled):
        """
        Main parsing function. This function parses the whole code string provided, as well as collects the data
        in the proper structures, retrievable from the various getter functions. If any problem occurs, the exceptions
        are saved in the final parsing status.

        :param code: Python code to be parsed
        :type code: str
        :param description_enabled: flag to determine whether the description needs to be generated or not
        :type description_enabled: bool
        """
        self.total_lines = code.count("\n")
        # try:
        self.reset(code, description_enabled)
        module = astroid.parse(code)
        for node in module.body:
            parsed = self.get_parsed_node(node)
            if parsed:
                self._stack.append(parsed)
        # except Exception as exc:
        #     self.exceptions.append(str(exc))
