from dataclasses import field, dataclass


from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class AssertStatement(BaseNode):
    genus: str = "assert_statement"
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["error_control", "flow_control"]
    )
    test: Container.every_node = None
    fail: Container.every_node = None

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"::assert:: {self.test.get_description}."

        if self.fail.genus != "none_type":
            humanized += f" If it fails, exit with message {self.fail.get_description}."

        return humanized
