def assign_simple():
    a = 5
    b = 10
    d = f = 4
    x = l.k.G(14)
    p = E(w=1, s=3)
