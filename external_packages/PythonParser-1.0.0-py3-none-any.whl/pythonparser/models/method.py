from dataclasses import field, dataclass

from typing import List
from dataclasses_json import dataclass_json
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

TYPES = {
    "str": "string",
    "int": "integer",
    "float": "float",
    "bool": "boolean",
    "NoneType": "none",
    "complex": "complex",
    "Ellipsis": "ellipsis",
    "bytes": "bytes",
    "dict": "dictionary",
    "list": "list",
    "tuple": "tuple",
}

METHODS_DEFINITION = {
    "__init__": "Initializator",
    "__del__": "Destructor",
    "__new__": "Constructor",
    "__repr__": "(Formal) String representation",
    "__str__": "(Informal) String representation",
    "__format__": "Formatted string representation",
    "__bytes__": "Bytes representation",
    "__bool__": "Boolean representation",
    "__hash__": "Hash representation",
    "__lt__": "Less Than",
    "__le__": "Less or Equal",
    "__eq__": "Equal",
    "__ne__": "Not Equal",
    "__gt__": "Greater Than",
    "__ge__": "Greater or Equal",
    "__iter__": "Iterator representation",
    "__next__": "Next iterated element representation",
    "__len__": "Lenght representation",
    "__contains__": "Elements contained representation",
    "__copy__": "Copy the class instance",
}


@dataclass_json
@dataclass
class Method(BaseNode):
    name: str = ""
    documentation: str = ""
    returns: str = ""
    star_parameters_count: int = 0
    total_lines: int = 0
    decorators: Container.every_node = None
    parameters: List[Container.every_node] = field(default_factory=list)
    body: List[Container.every_node] = field(default_factory=list)
    inner_methods: List[str] = field(default_factory=list)
    is_class_method: bool = False
    parent_class: str = ""
    genus: str = "function"
    element_categories: List[str] = field(
        default_factory=lambda: ["context_manager", "structural", "functional"]
    )
    is_subset: bool = True

    code = ""

    def additional_final_operations(self):
        """Performs few final operations before leaving the current node.
        Adds the method node, the method code, and the
        method generated description to the container."""
        class_identifier, method_identifier = self.container.get_current_class_method()
        if class_identifier:
            self.genus = "class_method"

        self.container.add_method(self)
        self.container.add_method_code(
            {
                "name": self.name,
                "code": self.code,
                "start_line": self.start_line,
                "end_line": self.end_line,
            }
        )
        self.add_method_description(class_identifier)

    def add_method_description(self, class_name):
        """Add the method (and class in case of __init__ or __new__ methods) to methods_descriptions"""
        if not self.name or not self.container.get_description_flag():
            return
        else:
            description = self.description

        method_dict = {
            "method_name": self.name,
            "class_name": class_name,
            "method_significance": METHODS_DEFINITION.get(self.name, ""),
            "description": "",
        }

        functions_descriptions = self.container.get_functions_descriptions()
        for method_description in functions_descriptions:
            if (
                method_description["method_name"] == self.name
                and method_description["class_name"] == class_name
            ):
                method_dict = method_description
                self.container.remove_function_description(method_description)
                break

        if method_dict["description"] == "":
            method_dict["description"] = f"Description of method {self.name}."

        method_dict["description"] += "\n" + description
        self.container.add_function_description(method_dict)

        if self.name == "__init__" or self.name == "__new__" and class_name:
            class_dict = {"class_name": class_name, "description": "", "methods": []}

            methods_descriptions = self.container.get_methods_descriptions()

            for class_description in methods_descriptions:
                if class_description["class_name"] == class_name:
                    class_dict = class_description
                    self.container.remove_method_description(class_description)
                    break

            if class_dict["description"] == "":
                class_dict["description"] = f"Description of class {class_name}."

            class_dict["description"] += "\n" + method_dict["description"]
            class_dict["methods"].append(self.name)
            self.container.add_method_description(class_dict)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        if self.is_class_method:
            humanized = f"The ^^{self.parent_class}^^ class method %{self.name}$$ has "
        else:
            humanized = f"The function $${self.name}$$ has "

        if self.decorators:
            humanized += f"the {self.decorators.get_description}. "
        else:
            humanized += "no decorator. "

        if self.parameters:
            humanized += (
                "The following parameters are expected: "
                + f"{', '.join([param.get_description for param in self.parameters])}. "
            )

        if self.inner_methods:
            humanized += f"This function has the following inner methods: {', '.join(self.inner_methods)}"

        if self.returns:
            humanized += (
                f"The expected return is a {TYPES.get(self.returns, self.returns)}. "
            )

        humanized += "The statements executed in the function's body are: "

        for body in self.body:
            if body.genus in ("class", "function", "class_method"):
                corrected_body = f"{body.get_description[:body.get_description.find('has')]}is defined"

            else:
                corrected_body = body.get_description.replace("\t", "\t\t")

            corrected_body = corrected_body.strip(".").strip("")
            humanized += f"\n\t- {corrected_body};"

        humanized = f"{humanized.strip(';').strip('.')}.\n"
        return humanized
