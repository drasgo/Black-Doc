import logging
import threading
import os
from kafka.admin import KafkaAdminClient, NewTopic
from kafka.errors import TopicAlreadyExistsError
from functionalities.firstOrder import *
from functionalities.statistical import *
from baseProcessorFunctionality import BaseProcessorFunctionality
from baseProducer import BaseProducer
from config_files.utils import create_dir
from config_files.utils import safely_load_json

logger = logging.getLogger(__name__)

KAFKA_PRODUCER_CONFIG_JSON = os.path.abspath("config_files/kafka_producer_config.json")
"""
Default path for json with data to connect a producer to Kafka
"""


class ProcessorManager:
    checkpoint_dir = os.path.relpath("./HDFS_checkpoint")

    def __init__(self, consumer, sparkContext, numberProcessors):
        self.consumer = consumer
        self.test = consumer.test
        self.inputTopic = consumer.topic
        self.pool = []
        self.processorsWhiteList = numberProcessors
        self.processors_producers = self.getProcessorProducer(
            self.getFunctionalities(self.inputTopic, sparkContext)
        )
        self.test = False

        if self.test is False:
            self.kafka_config = safely_load_json(KAFKA_PRODUCER_CONFIG_JSON)
            self.bootstrapServer = self.kafka_config["bootstrap_server"]
            self.consumer.setBootstrapServer(bootstrapServer=self.bootstrapServer)
            create_dir(self.checkpoint_dir)

            for elem in self.processors_producers:
                processorCheckpointDir = (
                    self.checkpoint_dir + "/" + elem["functionality"].name
                )
                create_dir(processorCheckpointDir)
                elem["producer"].connectionSetup(
                    self.bootstrapServer, processorCheckpointDir
                )

            self._create_topics(self.bootstrapServer)

        else:
            self.kafka_config = None
            self.bootstrapServer = None

    def getTopics(self):
        topics = []
        for elem in self.processors_producers:
            topics.append(elem["functionality"].inputTopic)
            topics.append(elem["producer"].topic)
        topics.append(self.consumer.topic)

        return topics

    def _create_topics(self, bootstrapServer):
        """
        Creates topics on kafka
        """
        admin_client = KafkaAdminClient(
            bootstrap_servers=[bootstrapServer], client_id="topics_manager"
        )

        for t in self.getTopics():
            try:
                topic_list = [NewTopic(name=t, num_partitions=1, replication_factor=1)]
                admin_client.create_topics(new_topics=topic_list, validate_only=False)
            except TopicAlreadyExistsError as e:
                logger.debug("Topic %s already exists on kafka", t)
                continue
            except Exception as e:
                logger.error(
                    "An error occurred while trying to create topic %s Error occured %s",
                    t,
                    e,
                )

        admin_client.close()

    def addFunc2SparkContext(self, func, sparkContext):
        sparkContext.addPyFile(func.getPath())

    def getFunctionalities(self, inputTopic, sparkContext):
        processors = []
        logger.info("Collecting Functionalities")
        for processor in BaseProcessorFunctionality.__subclasses__():
            assert issubclass(processor, BaseProcessorFunctionality)
            # Checks that the processor is for testing or not, if it is available (ready) and if its input topic is
            # this consumer's one
            if (
                (
                    (processor.testingFunctionality is True and self.test is True)
                    or (processor.testingFunctionality is False and self.test is False)
                )
                and processor.available is True
                and processor.inputTopic == inputTopic
            ):

                proc = processor()
                # If a processor whitelist file was provided than it checks if it is allowed
                if len(self.processorsWhiteList) == 0 or any(
                    elem.lower().replace(" ", "").replace("\n", "").replace("\t", "")
                    == proc.name.lower()
                    for elem in self.processorsWhiteList
                ):
                    self.addFunc2SparkContext(proc, sparkContext)
                    logger.info("Processor %s started correctly", proc.name)
                    processors.append(proc)

        return processors

    def getProducer(self, outputTopic):
        # Get every producer which inherits from BaseProducer
        for producer in BaseProducer.__subclasses__():
            assert issubclass(producer, BaseProducer)
            if (self.test is True and producer.testingProducer is True) or (
                self.test is False and producer.testingProducer is False
            ):
                if producer.topic == outputTopic:
                    prod = producer(self.test, self)
                    return prod
        return None

    def getProcessorProducer(self, processors):
        tot = []
        for proc in processors:
            temp = dict()
            temp["functionality"] = proc

            temp["producer"] = self.getProducer(proc.outputTopic)
            if temp["producer"] is not None:
                temp["functionality"].setSerializationSchema(
                    temp["producer"].getSerializationSchema()
                )
                tot.append(temp)
        return tot

    def run(self):
        data = self.consumer.getData()
        for pp in self.processors_producers:
            th = threading.Thread(target=self.pipeline, args=(pp, data), daemon=False)
            th.start()

    def pipeline(self, pp, data):
        processedData = pp["functionality"].processData(data, self.processors_producers)
        pp["producer"].publish(processedData)
