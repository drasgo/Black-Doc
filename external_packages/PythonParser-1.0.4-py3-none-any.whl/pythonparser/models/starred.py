from dataclasses import field, dataclass

from typing import Optional, List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Starred(BaseNode):
    stored: Optional[bool] = None
    value: Container.every_node = None
    genus: str = "starred_attribute"
    element_categories: List[str] = field(
        default_factory=lambda: ["structural", "identifier", "packed"]
    )

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        if self.stored:
            humanized = f"storing value(s) into {self.value.get_description}"
        else:
            humanized = f"loading value(s) from {self.value.get_description}"
        return humanized
