from dataclasses import field, dataclass


from typing import List, Optional

from pythonparser.models.baseNode import BaseNode

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class DictUnpack(BaseNode):
    genus: str = "dict_unpack"
    element_categories: List[str] = field(
        default_factory=lambda: ["operation", "dictionary"]
    )
    node_as_string: str = ""
    kind: Optional[str] = None
    cognitive_cost: int = 2

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"unpacking {self.node_as_string}"
        return humanized
