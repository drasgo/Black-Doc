from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Execute(BaseNode):
    value: Container.every_node = None
    genus: str = "statement_execution"
    element_categories: List[str] = field(
        default_factory=lambda: ["structural", "functional"]
    )

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"execute {self.value.get_description}"
        return humanized
