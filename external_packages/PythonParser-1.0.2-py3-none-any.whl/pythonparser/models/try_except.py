from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class TryExcept(BaseNode):
    genus: str = "try_except"
    element_categories: List[str] = field(default_factory=lambda: ["flow_control"])
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["flow_control", "error_handling"]
    )
    try_block: List[Container.every_node] = field(default_factory=list)
    exception: Container.every_node = None
    orelse_block: List[Container.every_node] = field(default_factory=list)
    final_body: List[Container.every_node] = field(default_factory=list)
    cognitive_cost = 3

    def additional_final_operations(self):
        self.container.add_exception(self)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = (
            f"::try{'-except' if self.exception else ''}{'-finally::' if self.final_body else '::'} "
            f"statement for handling the errors that may be encountered in the try block. "
        )

        humanized += (
            "In the ::try:: block there are the following statements: "
            + "; ".join(["\n- " + state.get_description for state in self.try_block])
        )

        if self.exception:
            humanized += self.exception.get_description

        if self.final_body:
            humanized += (
                "\nAfterward, in the ::finally:: body the following statements are executed: "
                + "; ".join(
                    ["\n- " + final.get_description for final in self.final_body]
                )
            )

        return humanized
