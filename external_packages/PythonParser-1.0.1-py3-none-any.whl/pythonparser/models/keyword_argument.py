from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class KeywordArgument(BaseNode):
    name: str = str()
    genus: str = "keyword"
    element_categories: List[str] = field(
        default_factory=lambda: ["arguments", "parameters"]
    )
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["passing_values", "receiving_values"]
    )
    value: Container.every_node = None

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = ""
        if self.value.description:
            humanized = (
                f"{self.value.get_description} passed to keyword ~~{self.name}~~"
            )

        return humanized
