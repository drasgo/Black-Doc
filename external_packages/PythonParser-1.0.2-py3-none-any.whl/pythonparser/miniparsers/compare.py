from astroid.nodes import Compare
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.comparison import Comparison


def parse_compare(node: Compare, container: Container) -> BaseNode:
    """Miniparser for Astroid's Compare node.
    The extracted information are saved in the Comparison node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Compare
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Comparison()
    data_model.initialization(container, node)

    data_model.left_hand = data_model.parse_node(node.left)

    for child in node.ops:
        (op, operand) = child
        parsed = data_model.parse_node(operand)
        data_model.operator = op
        data_model.right_hand = parsed

    data_model.final_operations()
    return data_model
