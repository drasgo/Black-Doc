import astroid
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.formatted_val import FormattedValue


def parse_formatted_value(
    node: astroid.nodes.FormattedValue, container: Container
) -> BaseNode:
    """Miniparser for Astroid's Formatted Value node.
	The extracted information are saved in the FormattedValue node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: astroid.nodes.FormattedValue
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = FormattedValue()
    data_model.initialization(container, node)

    data_model.value = data_model.parse_node(node.value)
    data_model.format_spec = data_model.parse_node(node.format_spec)

    data_model.final_operations()
    return data_model
