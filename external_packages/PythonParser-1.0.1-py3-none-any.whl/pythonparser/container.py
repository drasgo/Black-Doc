from typing import Tuple, List

from pythonparser.models.baseNode import BaseNode


class Container:
    every_node = None

    def __init__(self):
        self.description_flag = False
        self.total_code = ""
        self.node = None

        self.total_context = [{"type": "", "name": ""}]

        self.current_object_attributes = []
        self.current_class_attributes = []

        self.imports_summary = []
        self.assignments_summary = []
        self.returns_summary = []
        self.total_returns_summary = []
        self.calls_summary = []
        self.total_calls_summary = []
        self.classes_summary = []
        self.exceptions_summary = []
        self.methods_summary = []

        self.cached_imports_summary = []
        self.cached_assignments_summary = []
        self.cached_returns_summary = []
        self.cached_total_returns_summary = []
        self.cached_calls_summary = []
        self.cached_total_calls_summary = []
        self.cached_classes_summary = []
        self.cached_exceptions_summary = []
        self.cached_methods_summary = []

        self.methods_code = []
        self.methods_descriptions = {"class_methods": [], "functions": []}

    def reset(self, code: str, description_flag: bool):
        """Resets all the contained extracted information.

        :param code: string containing the Python code
        :type code: str
        :param description_flag: flag for defining wether the description needs to be generated
        :type description_flag: bool
        """
        self.description_flag = description_flag
        self.total_code = code
        self.node = None

        self.total_context = [{"type": "", "name": ""}]

        self.current_object_attributes = []
        self.current_class_attributes = []

        self.imports_summary = []
        self.assignments_summary = []
        self.returns_summary = []
        self.total_returns_summary = []
        self.calls_summary = []
        self.total_calls_summary = []
        self.classes_summary = []
        self.exceptions_summary = []
        self.methods_summary = []

        self.cached_imports_summary = []
        self.cached_assignments_summary = []
        self.cached_returns_summary = []
        self.cached_total_returns_summary = []
        self.cached_calls_summary = []
        self.cached_total_calls_summary = []
        self.cached_classes_summary = []
        self.cached_exceptions_summary = []
        self.cached_methods_summary = []

        self.methods_code = []
        self.methods_descriptions = {"class_methods": [], "functions": []}

    def set_context(self, context: dict):
        """Setter of the current total context. Reset the total context to what is passed as context.

        :param context: current total context
        :type context: dict
        """
        self.total_context = context

    def add_context(self, current_context: dict):
        """Add the current context to the total context.

        :param current_context: current node context
        :type current_context: dict
        """
        self.total_context.append(current_context)

    def add_import(self, import_element: BaseNode):
        """Add the import node to the collection of all the imports in the Python code

        :param import_element: new import node
        :type import_element: BaseNode
        """
        self.imports_summary.append(import_element)

    def add_assignment(self, assignment_element: BaseNode):
        """Add the assignment node to the collection of all the assignments in the Python code.

        :param assignment_element: new assignment node
        :type assignment_element: BaseNode
        """
        self.assignments_summary.append(assignment_element)

    def add_return(self, return_element: dict):
        """Add the simplified return node to the collection of all the simplified returns in the Python code.

        :param return_element: new simplified version of return node
        :type return_element: dict
        """
        self.returns_summary.append(return_element)

    def add_total_return(self, return_element: BaseNode):
        """Add the return node to the collection of all the returns in the Python code.

        :param return_element: new return node
        :type return_element: BaseNode
        """
        self.total_returns_summary.append(return_element)

    def add_total_call(self, call_element: BaseNode):
        """Add the call node to the collection of all the calls in the Python code.

        :param call_element: new call node
        :type call_element: BaseNode
        """
        self.total_calls_summary.append(call_element)

    def add_call(self, call_element: dict):
        """Add the simplified call node to the collection of all the simplified calls in the Python code.

        :param call_element: new simplified version of call node
        :type call_element: dict
        """
        self.calls_summary.append(call_element)

    def add_class(self, class_element: BaseNode):
        """Add the class node to the collection of all the classes in the Python code.

        :param class_element: new class node
        :type class_element: BaseNode
        """
        self.classes_summary.append(class_element)

    def add_exception(self, exception_element:BaseNode):
        self.exceptions_summary.append(exception_element)

    def add_method(self, method_element: BaseNode):
        """Add the method node to the collection of all the methods in the Python code.

        :param method_element: new method node
        :type method_element: BaseNode
        """
        self.methods_summary.append(method_element)

    def add_method_code(self, method_code: dict):
        """Add the method code to the collection of all the method codes in the Python code.

        :param method_code: code of new method
        :type method_code: dict
        """
        self.methods_code.append(method_code)

    def add_method_description(self, description: dict):
        """Add the generated description of a new class method to the collection of all the method descriptions generated
         for methods in the Python code.

         :param description: dictionary containing information of the method and its generated description
         :type description: dict
         """
        self.methods_descriptions["class_methods"].append(description)

    def add_function_description(self, description: dict):
        """Add the description of a new function to the collection of all the functions descriptions generated
         for methods in the Python code.

         :param description: dictionary containing information of the function and its generated description
         :type description: dict
         """
        self.methods_descriptions["functions"].append(description)

    def add_current_class_attribute(self, attribute: BaseNode):
        """Add single class attribute to the temporary collection containing the class attributes of
        the class (/one of the classes) currently visiting.

        :param attribute: new class attribute node
        :type attribute: BaseNode
        """
        self.current_class_attributes.append(attribute)

    def add_current_object_attribute(self, attribute: BaseNode):
        """Add single object attribute to the temporary collection containing the object attributes of
        the class (/one of the classes) currently visiting.

        :param attribute: new class object node
        :type attribute: BaseNode
        """
        self.current_object_attributes.append(attribute)

    def remove_current_class_attributes(self):
        """Reset the temporary collection of class attributes"""
        self.current_class_attributes = []

    def remove_current_object_attribute(self):
        """Reset the temporary collection of object attributes"""
        self.current_object_attributes = []

    def remove_current_context(self):
        """Remove last context layer from the current total context"""
        self.total_context.pop()

    def remove_method_description(self, description: dict):
        """Remove the description specified from the collection of class methods descriptions.

        :param description: description to be removed
        :type description: dict
        """
        self.methods_descriptions["class_methods"].remove(description)

    def remove_function_description(self, description: dict):
        """Remove the description specified from the collection of functions descriptions.

        :param description: description to be removed
        :type description: dict
        """
        self.methods_descriptions["functions"].remove(description)

    def get_description_flag(self) -> bool:
        """Returns the specified flag for generating or not the description of every node.

        :returns: bool - True -> generate description, False -> do not generate it
        """
        return self.description_flag

    def get_current_class_method(self) -> Tuple[str, str]:
        """Returns in which method and/or class the node resides.

        :returns: Tuple[str, str] - class name and method name in which the current node resides in
        """
        class_identifier = ""
        method_identifier = ""
        context = self.get_context()

        if context:
            for cont in reversed(context):
                if not method_identifier and cont["type"] in [
                    "function",
                    "class_method",
                ]:
                    method_identifier = cont["name"]

                if not class_identifier and cont["type"] == "class":
                    class_identifier = cont["name"]

                if method_identifier and class_identifier:
                    break

        return class_identifier, method_identifier

    def get_context_scope(self) -> str:
        """Returns the current context scope, i.e. in which scope the current node is in.

        :returns: str - it can be either "global", "class_method", "function", or "class"
        """
        origin_class, origin_method = self.get_current_class_method()
        context_scope = "global"

        if origin_method:
            if origin_class:
                context_scope = "class_method"
            else:
                context_scope = "function"
        elif origin_class:
            context_scope = "class"
        return context_scope

    def get_context(self) -> List[dict]:
        """Getter method returning the current total context.

        :returns: List[dict] - list containing all the layered scope that make the current context
        """
        return self.total_context

    def get_imports(self) -> List[dict]:
        """Getter method returning all the import nodes in the Python code.

        :returns: List[dict] - list containing all the import nodes
        """
        if not self.cached_imports_summary:
            for element in self.imports_summary:
                converted_element = element.to_dict()
                self.cached_imports_summary.append(converted_element)
        return self.cached_imports_summary

    def get_assignments(self) -> List[dict]:
        """Getter method returning all the assignment nodes in the Python code.

        :returns: List[dict] - list containing all the assignment nodes
        """
        if not self.cached_assignments_summary:
            for element in self.assignments_summary:
                converted_element = element.to_dict()

                self.cached_assignments_summary.append(converted_element)
        return self.cached_assignments_summary

    def get_returns(self) -> List[dict]:
        """Getter method returning all the simplified return nodes in the Python code.

        :returns: List[dict] - list containing all the simplified return nodes
        """
        return self.returns_summary

    def get_total_returns(self) -> List[dict]:
        """Getter method returning all the return nodes in the Python code.

        :returns: List[dict] - list containing all the return nodes
        """
        if not self.cached_total_returns_summary:
            for element in self.total_returns_summary:
                converted_element = element.to_dict()

                self.cached_total_returns_summary.append(converted_element)
        return self.cached_total_returns_summary

    def get_calls(self) -> List[dict]:
        """Getter method returning all the simplified call nodes in the Python code.

        :returns: List[dict] - list containing all the simplified call nodes
        """
        return self.calls_summary

    def get_total_calls(self) -> List[dict]:
        """Getter method returning all the call nodes in the Python code.

        :returns: List[dict] - list containing all the call nodes
        """
        if not self.cached_total_calls_summary:
            for element in self.total_calls_summary:
                converted_element = element.to_dict()

                self.cached_total_calls_summary.append(converted_element)
        return self.cached_total_calls_summary

    def get_classes(self) -> List[dict]:
        """Getter method returning all the class nodes in the Python code.

        :returns: List[dict] - list containing all the class nodes
        """
        if not self.cached_classes_summary:
            for element in self.classes_summary:
                converted_element = element.to_dict()

                self.cached_classes_summary.append(converted_element)
        return self.cached_classes_summary

    def get_exceptions(self) -> List[dict]:
        """Getter method returning all the class nodes in the Python code.

        :returns: List[dict] - list containing all the class nodes
        """
        if not self.cached_exceptions_summary:
            for element in self.exceptions_summary:
                self.cached_exceptions_summary.append(element.to_dict())
        return self.cached_exceptions_summary


    def get_methods(self) -> List[dict]:
        """Getter method returning all the method nodes in the Python code.

        :returns: List[dict] - list containing all the method nodes
        """
        if not self.cached_methods_summary:
            for element in self.methods_summary:
                converted_element = element.to_dict()

                self.cached_methods_summary.append(converted_element)
        return self.cached_methods_summary

    def get_descriptions(self) -> dict:
        """Getter method returning all the generated descriptions.

        :returns: dict - dictionary containing all the generated descriptions, divided in
        "class_methods" and "functions"
        """
        return self.methods_descriptions

    def get_functions_descriptions(self) -> List[dict]:
        """Getter method returning the generated description of all the functions in the Python code.

        :returns: List[dict] - list containing the generated descriptions of every function
        """
        return self.methods_descriptions["functions"]

    def get_methods_descriptions(self) -> List[dict]:
        """Getter method returning the generated description of all the class methods in the Python code.

        :returns: List[dict] - list containing the generated descriptions of every class method
        """
        return self.methods_descriptions["class_methods"]

    def get_methods_code(self) -> List[dict]:
        """Getter method returning the code of all the methods in the Python code.

        :returns: List[dict] - list containing the code of every method
        """
        return self.methods_code

    def get_current_class_attributes(self, cls_name: str) -> List[dict]:
        """Getter method returning the class attributes of the requested class.

        :param cls_name: requested class
        :type cls_name: str
        :returns: List[dict] - list containing the class attributes of the class cls_name
        """
        class_attributes = []

        for idx in range(len(self.current_class_attributes)):
            if self.current_class_attributes[idx]["class"] == cls_name:
                del self.current_class_attributes[idx]["class"]
                class_attributes.append(self.current_class_attributes[idx])

        for element in class_attributes:
            self.current_class_attributes.remove(element)

        return class_attributes

    def get_current_object_attributes(self, cls_name: str) -> List[dict]:
        """Getter method returning the object attributes of the requested class.

        :param cls_name: requested class
        :type cls_name: str
        :returns: List[dict] - list containing the object attributes of the class cls_name
        """

        object_attributes = []

        for idx in range(len(self.current_object_attributes)):
            if self.current_object_attributes[idx]["class"] == cls_name:
                del self.current_object_attributes[idx]["class"]
                object_attributes.append(self.current_object_attributes[idx])

        for element in object_attributes:
            self.current_object_attributes.remove(element)

        return object_attributes
