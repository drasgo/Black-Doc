from dataclasses import dataclass
from enum import Enum
from typing import Dict
from dataclasses_json import dataclass_json
from pythonparser.models.baseNode import BaseNode

TypeSource = Enum(
    "TypeSource", "Python External_Import Internal_Import Scope_Defined Undefined"
)


@dataclass_json
@dataclass
class TypeHint(BaseNode):
    source: Dict[TypeSource, str] = TypeSource.Undefined
    kind: str = str()

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node

        TODO: implement this"""
        humanized = ""
        return humanized


if __name__ == "__main__":
    src = TypeSource.Python.name
    type_hint = TypeHint(source={src: "python"}, kind="str")
    print(type_hint.to_json())
