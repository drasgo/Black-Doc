from astroid.nodes import UnaryOp

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.unary_op import UnaryOperation


def parse_unary_op(node: UnaryOp, container: Container) -> BaseNode:
    """Miniparser for Astroid's Unary Operation node.
    The extracted information are saved in the UnaryOperation node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: UnaryOp
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = UnaryOperation()
    data_model.initialization(container, node)

    data_model.op = node.op
    for child in node.get_children():
        data_model.operand = data_model.parse_node(child)

    data_model.final_operations()
    return data_model
