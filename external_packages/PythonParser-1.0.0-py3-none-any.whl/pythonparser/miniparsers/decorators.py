from astroid.nodes import Decorators

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.decorator import Decorator


def parse_decorators(node: Decorators, container: Container) -> BaseNode:
    """Miniparser for Astroid's Decorators node.
    The extracted information are saved in the Decorator node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Decorators
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Decorator()
    data_model.initialization(container, node)

    for node in node.nodes:
        data_model.decorators.append(node.as_string())

    data_model.final_operations()
    return data_model
