from astroid.nodes import Assert
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.assert_statement import AssertStatement


def parse_assert(node: Assert, container: Container) -> BaseNode:
    """Miniparser for Astroid's Assert node.
	The extracted information are saved in the AssertStatement node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: Assert
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = AssertStatement()
    data_model.initialization(container, node)

    data_model.test = data_model.parse_node(node.test)
    data_model.fail = data_model.parse_node(node.fail)

    data_model.final_operations()
    return data_model
