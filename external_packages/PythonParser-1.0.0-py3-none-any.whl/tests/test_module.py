import os
from typing import List, Tuple
from pyspark.sql.functions import min as _min, max as _maxi
from a_package.b import AClass as ImportedClass
from ..xyz.functions import test_import
import json, sys

import pandas as pd


def x(abs):
    """
	A docstring
	"""
    if type(abs) == float:
        abs = int(abs)

    return str(abs)


def function(x: int, y: float = 1.1) -> Tuple[float, float]:
    """
    Lorem ipsum
    """
    x = float(x)
    try:
        1 + x / y
    except ZeroDivisionError:
        print("No division by zero allowed")

    return x, y + x


def factorial(n: int):
    if n == 0:
        return 1
    return n * factorial(n - 1)


class ClassCommon:
    """
    This class appears with the same name and methods in another module
    """

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def product(self):
        return x * y * z


def another_function(x, y, z):
    """
	Some docs just for testing
	"""
    # Instantiate a class
    c = ClassCommon(x, y, z)
    return c.product()
