import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.global_mod import Global


def parse_global(node: astroid.nodes.Global, container: Container) -> BaseNode:
    """Miniparser for Astroid's Global node.
	The extracted information are saved in the Global node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: Global
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Global()
    data_model.initialization(container, node)

    data_model.names = node.names

    data_model.final_operations()
    return data_model
