from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class FormattedValue(BaseNode):
    value: Container.every_node = None
    format_spec: str = field(default_factory=str)
    genus: str = "formatted_value"
    element_categories: List[str] = field(
        default_factory=lambda: ["formatted_value", "structural"]
    )

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"formatted {self.value.get_description}"
        return humanized
