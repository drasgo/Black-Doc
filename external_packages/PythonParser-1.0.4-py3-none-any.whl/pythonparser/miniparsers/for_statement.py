from astroid.nodes import For
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.for_loop import ForLoop


def parse_for(node: For, container: Container) -> BaseNode:
    """Miniparser for Astroid's For node.
    The extracted information are saved in the ForLoop node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: For
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = ForLoop()
    data_model.initialization(container, node)

    for statement in node.body:
        parsed_statement = data_model.parse_node(statement)
        data_model.statements.append(parsed_statement)

    for alternative in node.orelse:
        parsed_alternative = data_model.parse_node(alternative)
        data_model.orelse_block.append(parsed_alternative)

    data_model.iterable = data_model.parse_node(node.iter)
    data_model.pointer = data_model.parse_node(node.target)

    data_model.final_operations()
    return data_model
