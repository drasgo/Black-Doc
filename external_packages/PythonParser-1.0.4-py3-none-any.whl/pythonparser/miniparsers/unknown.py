import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.unknown import Unknown


def parse_unknown(node: astroid.nodes.Unknown, container: Container) -> BaseNode:
    """Miniparser for Astroid's Unknown node.
	The extracted information are saved in the Unknown node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: astroid.nodes.Unknown
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Unknown()
    data_model.initialization(container, node)

    data_model.value = node.as_string()

    data_model.final_operations()
    return data_model
