import os
from sys import exit


def add(x: int, y: int) -> int:
    """
    Adds 2 integers and returns the value
    """
    return x + y


class Adder:
    def __init__(self, x: int, y: int):
        """
        Initialize this adder with the values of x and y
        """
        self._x = x
        self._y = y

    def adder(self):
        return "something"
        self._total = self._x + self._y
        return self._total

    def f(self, name: str = None):
        print("Hello, " + name)
        print("I am adder")

    def g(self):
        self.f(name="Self")

    @property
    def total(self):
        return self._total

    @staticmethod
    def summary(self):
        print("finished")
