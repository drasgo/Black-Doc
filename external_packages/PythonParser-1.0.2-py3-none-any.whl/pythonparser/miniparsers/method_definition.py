from astroid.nodes import FunctionDef

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.argument import Argument
from pythonparser.models.method import Method


def parse_method(node: FunctionDef, container: Container) -> BaseNode:
    """Miniparser for Astroid's Function Definition node.
    The extracted information are saved in the Method node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: FunctionDef
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Method()
    data_model.initialization(container, node)

    data_model.code = node.as_string()
    data_model.name = node.name
    data_model.add_current_context(data_model.name)

    cls, _ = data_model.container.get_current_class_method()
    if cls:
        data_model.is_class_method = True
        data_model.parent_class = cls

    data_model.documentation = node.doc if node.doc else ""
    data_model = parse_arguments(data_model, node.args, container)

    if node.decorators:
        data_model.decorators = data_model.parse_node(node.decorators)

    if node.returns:
        data_model.returns = node.returns.as_string() if node.returns else None

    for statement in node.body:
        parsed_statement = data_model.parse_node(statement)
        data_model.body.append(parsed_statement)

        if isinstance(statement, FunctionDef):
            data_model.inner_methods.append(parsed_statement.name)

    data_model.remove_current_context()

    data_model.final_operations()
    return data_model


def parse_arguments(data_model: Method, args, container: Container) -> BaseNode:
    """Parse method arguments.

    :param data_model: Function node
    :type data_model: Method
    :param args: collection of arguments passed to the method
    :param container: Container object to hold parsed and extracted information
    :type container: Container
    :returns: BaseNode - Method node
    """
    if args.vararg or args.kwarg:
        arg = Argument()
        arg.container = container

        if args.vararg:
            arg.name = args.vararg
            arg.is_vararg = True

        else:
            arg.name = args.kwarg
            arg.is_kwarg = True

        arg.final_operations()

        arg.start_line = data_model.node.fromlineno
        arg.end_line = data_model.node.fromlineno

        data_model.parameters.append(arg)
        data_model.star_parameters_count += 1

    for arg_index in range(len(args.args)):
        arg = Argument()
        arg.initialization(container, args.args[arg_index])

        arg.name = args.args[arg_index].as_string()
        arg.param_type_hint = (
            args.annotations[arg_index].as_string()
            if args.annotations[arg_index]
            else ""
        )

        if args.defaults and arg_index + len(args.defaults) - len(args.args) >= 0:
            arg.value = args.defaults[
                arg_index + len(args.defaults) - len(args.args)
            ].as_string()
            arg.value = arg.value.replace("'", '"')

        arg.final_operations()
        data_model.parameters.append(arg)

    return data_model
