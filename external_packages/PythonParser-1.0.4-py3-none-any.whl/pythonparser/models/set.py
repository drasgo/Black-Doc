from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class SetContainer(BaseNode):
    genus: str = "set"
    element_categories: List[str] = field(
        default_factory=lambda: ["values_container", "data_structure"]
    )
    elements: List[Container.every_node] = field(default_factory=list)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"set of {str(len(self.elements))} elements"
        return humanized
