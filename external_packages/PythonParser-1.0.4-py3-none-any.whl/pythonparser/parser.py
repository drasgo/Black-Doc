import re
import copy
import logging
from typing import List

from pythonparser.concrete_full_parser import PythonConcreteFullParser

logger = logging.getLogger(__name__)
__version__ = "1.0.4"


class Parser:
    """
    Main class for Python source code parser. To the initializer accepts either the code or the file name of the Python
    file, and a flag to define if the description needs to be generated or not.
    """

    def __init__(
        self, code: str = "", file_name: str = "", description_enabled: bool = False
    ):
        """ Initializer of the class Parser. Accepts either the string Python code, or the file name that contains the
            code to be parsed. Then, it sets up the code which is going to be parsed.

            :param code: Optional string containing the Python code
            :type code: str
            :param file_name: Optional file name that contains the Python code
            :type file_name: str
        """
        self.code = ""
        self.description_enabled = description_enabled

        if code:
            self._set_code(code)
        elif file_name:
            try:
                with open(file_name, "r") as fp:
                    self._set_code(fp.read())
            except:
                logger.info("Error opening file " + file_name)

        self.concrete_tree_parser = PythonConcreteFullParser()

    def _set_code(self, code: str):
        """ Sets the cleaned up code string into the object variable code.

        :param code: String containing the code
        :type code: str
        """
        self.code = self.clean_code(code)

    def set_description_enabled(self, description_enabled: bool):
        """Set the boolean flag for enabling or diablsing the description generation.

        :param description_enabled: Boolean indicating wether the description needs to be generated or not.
        :type description_enabled: bool
        """
        self.description_enabled = description_enabled

    @staticmethod
    def clean_code(code: str):
        """Replace the tabulations with four spaces throughout the file, to have consistent indentation.

        :param code: String containing the code to be parsed.
        :type code: str
        :returns: str - the string with only spaces
        """
        return code.replace("\t", "    ")

    def parse(self):
        """
        Main parsing function. This function parses the whole code string provided, as well as collects the data
        in the proper structures, retrievable from the various getter functions.
        """
        if self.code:
            self.concrete_tree_parser.parse(self.code, self.description_enabled)
        else:
            self.code = ""
            logger.info("No code to be parsed")

    def description(self) -> dict:
        """
        Returns a dictionary with keys class_methods, which contains the class_name, description, method_name and
        method_significance of every class method in the file, and functions, which contains the description, method_name
        and method_significance of every global function in the file.

        :returns: dict - dictionary containing the descriptions divided in function and class method descriptions
        """
        original_description = self.concrete_tree_parser.get_descriptions()
        if (
            not original_description["class_methods"]
            and not original_description["functions"]
        ):
            return original_description

        generated_description = copy.deepcopy(original_description)
        for class_described in generated_description["class_methods"]:
            class_described["methods"] = []
        method_to_be_removed = []

        for method_description in generated_description["functions"]:
            class_name = method_description["class_name"]
            # Remove multiple dots like ".." or "..." from the generated descriptions
            method_description["description"] = [
                re.sub("[\.\.]+", ".", method_description["description"])
            ]
            del method_description["class_name"]

            if class_name:
                if all(
                    class_name != class_elem["class_name"]
                    for class_elem in generated_description["class_methods"]
                ):
                    generated_description["class_methods"].append(
                        {
                            "class_name": class_name,
                            "description": [""],
                            "methods": [method_description],
                        }
                    )

                else:
                    for class_elem in generated_description["class_methods"]:
                        if class_elem["class_name"] == class_name:
                            class_elem["methods"].append(method_description)
                            break

                method_to_be_removed.append(method_description)

        for method in method_to_be_removed:
            generated_description["functions"].remove(method)

        return generated_description

    def parsing_status(self) -> List[str]:
        """After having executed the "parse" function, here the parsing status can be retrieved. The parsing status is
        a list containing the exceptions that were encountered when parsing the Python code. If no exceptions were found,
        the list is empty.

        :returns: List[str] - contains all the exceptions encountered when parsing the Python code
        """
        return self.concrete_tree_parser.exceptions

    def classes(self) -> List[dict]:
        """ After having executed the "parse" function, here all the classes in the Python code can be retrieved.

        :returns: List[dict] - collection of all the classes as dictionaries found in the Python code
        """
        return self.concrete_tree_parser.get_classes_summary()

    def exceptions(self) -> List[dict]:
        return self.concrete_tree_parser.get_exceptions_summary()

    def calls(self) -> List[dict]:
        """ After having executed the "parse" function, here all the calls (in their "simplified" version) in the Python
         code can be retrieved.

        :returns: List[dict] - collection of all the calls (in their simplified version) as dictionaries in the Python code
        """
        return self.concrete_tree_parser.get_calls_summary()

    def total_calls(self) -> List[dict]:
        """ After having executed the "parse" function, here all the calls in the Python code can be retrieved.

        :return: List[dict] - collection of all the calls as dictionaries in the Python code
        """
        return self.concrete_tree_parser.get_total_calls_summary()

    def returns(self) -> List[dict]:
        """ After having executed the "parse" function, here all the returns (in their simplified version) in the Python
        code can be retrieved.

        :returns: List[dict] - collection of all the returns (in their simplified version) as dictionaries in the Python code
        """
        return self.concrete_tree_parser.get_returns_summary()

    def total_returns(self) -> List[dict]:
        """ After having executed the "parse" function, here all the returns in the Python code can be retrieved.

        :returns: List[dict] - collection of all the returns as dictionaries in the Python code
        """
        return self.concrete_tree_parser.get_total_returns_summary()

    def assignments(self) -> List[dict]:
        """ After having executed the "parse" function, here all the assignments in the Python code can be retrieved.

        :returns: List[dict] - collection of all the assignments as dictionaries in the Python code
        """
        return self.concrete_tree_parser.get_assignments_summary()

    def doc_strings(self, class_name: str) -> str:
        """After having executed the "parse" function, here the docstring for class class_name (if existing) is
        retrieved. If the class does not exist, an empty string is returned.

        :param class_name: name of the class we want to retrieve the docstring from
        :type class_name: str
        :returns: str - docstring of the class class_name, or an empty string if the class does not exist
        """
        return self.concrete_tree_parser.get_class_documentation(class_name)

    def number_of_lines(self, class_name: str) -> int:
        """ After having executed the "parse" function, here the number of lines of the class class_name, including
        docstrings, is retrieved. It is returned -1 if the class does not exist

        :param class_name: name of the class we want to retrieve the number of lines
        :type class_name: str
        :returns: int - number of lines for class class_name, or -1 if it does not exist
        """
        return self.concrete_tree_parser.get_class_number_of_lines(class_name)

    def methods(self, class_name: str) -> List[dict]:
        """ After having executed the "parse" function, here all the class methods for class class_name.

        :param class_name: name of the class we want to retrieve the methods from
        :type class_name: str
        :returns: List[dict] - collection of dictionaries containing information of one method each. The list will be
        empty if the class does not exist
        """
        return self.concrete_tree_parser.get_class_methods_summary(class_name)

    def imports(self) -> List[dict]:
        """ After having executed the "parse" function, here all the imports of the Python code are retrieved.

        :returns: List[dict] - collection of the imports as dictionaries in the Python code
        """
        return self.concrete_tree_parser.get_imports_summary()

    def functions(self) -> List[dict]:
        """ After having executed the "parse" function, here all the functions (not in classes) in the
        Python code are retrieved.

        :returns: List[dict] - collection of all the functions as dictionaries in the Python code
        """
        return self.concrete_tree_parser.get_functions_summary()

    def general_info(self) -> dict:
        """ After having executed the "parse" function, here some general information (such as the total number of lines)
        of the Python code are retrieved.

        :returns: dict - hash containing some general information of the Python code
        """
        return self.concrete_tree_parser.get_general_info()

    def functions_code(self) -> List[dict]:
        """ After having executed the "parse" function, here the code of all the functions in the Python code are
        retrieved.

        :returns: List[dict] - collection of the code of the functions in the Python code
        """
        return self.concrete_tree_parser.get_functions_code()

    def print(self):
        """Print the items contained in the parsed AST."""
        for item in self.concrete_tree_parser.get_stack():
            print(item)

    def to_dict(self):
        """Conversion to dictionary of the whole parsed AST"""
        return {"cst": self.concrete_tree_parser.get_stack()}


if __name__ == "__main__":

    def retrieve_results_test(filepath: str, exec_type: str = "multi"):
        """Used for debugging"""
        res = {"file": filepath}

        t_code = open(file_path, "r").read()
        pars = Parser(t_code, description_enabled=description)
        # pars = Parser(t_code, description_enabled=False)
        pars.parse()
        try:
            res[f"{exec_type}_total"] = pars.to_dict()
        except:
            print(file_path)

        res[f"{exec_type}_description"] = pars.description()
        res[f"{exec_type}_calls"] = pars.calls()
        res[f"{exec_type}_status"] = pars.parsing_status()
        res[f"{exec_type}_assignments"] = pars.assignments()
        res[f"{exec_type}_returns"] = pars.returns()
        res[f"{exec_type}_imports"] = pars.imports()
        res[f"{exec_type}_functions"] = pars.functions()
        res[f"{exec_type}_functions_code"] = pars.functions_code()

        return res

    def list_to_dict(res: list) -> dict:
        """Used for debugging"""
        final = {}
        for element in res:
            filename = element["file"]
            if filename not in final:
                final[filename] = {}
            final[filename].update(element)

        return final

    import pprint, multiprocessing

    # import json
    repo = False
    description = False
    # print(__version__)
    # file_path = "../tests/pydriller/pydriller/domain/commit.py"
    file_path = "../tests/core.py"
    if not repo:
        test_code = open(file_path).read()
        print("with description")
        parser = Parser(test_code, description_enabled=description)
        parser.parse()
        # print(json.dumps(parser.functions()))
        # pprint.pprint(parser.exceptions())
        pprint.pprint(parser.classes())
        # pprint.pprint(parser.returns() )
        input()
        # pprint.pprint(parser.functions_code())
        for d in parser.description()["class_methods"]:
            print(d["methods"])
            for m in d["methods"]:
                print(m["description"])
                # input()

    if repo is True:
        import os, time

        file_path = "../tests/pydriller/"
        # file_path = "tests/"
        processes = 12
        files = []
        for (dirpath, dirnames, filenames) in os.walk(str(file_path), topdown=True):
            for file in filenames:
                if file[-3:] != ".py" or file == "setup.py":
                    continue
                file_path = dirpath + ("/" if dirpath[-1] != "/" else "") + file
                files.append(file_path)

        time1 = time.time()
        results = []
        for file in files:
            results.append(retrieve_results_test(file, "normal"))

        print(
            f"Sequential processing for parsing {len(files)} is {time.time() - time1} seconds"
        )
        time1 = time.time()

        with multiprocessing.Pool(processes=processes) as pool:
            multi_results = pool.map(retrieve_results_test, files)

        print(
            f"Parallel processing for parsing {len(files)} is {time.time() - time1} seconds"
        )

        final_result = list_to_dict(results + multi_results)

        for elem in final_result:
            try:
                assert (
                    final_result[elem]["normal_total"]
                    == final_result[elem]["multi_total"]
                )
                assert (
                    final_result[elem]["normal_description"]
                    == final_result[elem]["multi_description"]
                )
                assert (
                    final_result[elem]["normal_calls"]
                    == final_result[elem]["multi_calls"]
                )
                assert (
                    final_result[elem]["normal_status"]
                    == final_result[elem]["multi_status"]
                )
                assert (
                    final_result[elem]["normal_assignments"]
                    == final_result[elem]["multi_assignments"]
                )
                assert (
                    final_result[elem]["normal_returns"]
                    == final_result[elem]["multi_returns"]
                )
                assert (
                    final_result[elem]["normal_imports"]
                    == final_result[elem]["multi_imports"]
                )
                assert (
                    final_result[elem]["normal_functions"]
                    == final_result[elem]["multi_functions"]
                )
                assert (
                    final_result[elem]["normal_functions_code"]
                    == final_result[elem]["multi_functions_code"]
                )
            except AssertionError:
                print(elem)
    print("Done!")
