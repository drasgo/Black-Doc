from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Call(BaseNode):
    name: str = str()
    # node_name: Dict = field(default_factory=dict)
    node_string: str = str()
    keyword_arguments: List[Container.every_node] = field(default_factory=list)
    constant_arguments: List[Container.every_node] = field(default_factory=list)
    positional_arguments: List[Container.every_node] = field(default_factory=list)
    complex_arguments: List[Container.every_node] = field(default_factory=list)
    source_path: List[str] = field(default_factory=list)
    arguments_count: int = 0

    genus: str = "call_statement"
    element_categories: List[str] = field(default_factory=lambda: ["flow_control"])
    element_sub_categories: List[str] = field(
        default_factory=lambda: [
            "method_call",
            "function_call",
            "instantiate_object",
            "computation",
        ]
    )

    cognitive_cost: int = 2

    arguments_string = []

    def additional_final_operations(self):
        """
        Performs few final operations before leaving the current node.
        Saves the complete call node and a simplified version of the call node into the container.
        """
        origin_class, origin_method = self.container.get_current_class_method()
        context_scope = self.container.get_context_scope()

        self.container.add_call(
            {
                "origin_class": origin_class,
                "origin_method": origin_method,
                "context_scope": context_scope,
                "complete_context": self.get_complete_context(),
                "line": self.start_line,
                "call": {"name": self.name, "arguments": self.arguments_string},
            }
        )
        self.container.add_total_call(self)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        # humanized = f"Execution of function \"{self.node_name['description']}\"."
        humanized = f"Execution of function $${self.node_string[:self.node_string.rfind('(')]}$$."
        # humanized = f"Execution of function \"{self.node_string}\"."

        if (
            self.keyword_arguments
            or self.constant_arguments
            or self.positional_arguments
            or self.complex_arguments
        ):
            humanized += " This call has the following arguments:"

            if self.keyword_arguments:
                humanized += f" {'; '.join(key.get_description for key in self.keyword_arguments)}; "

            if self.constant_arguments:
                humanized += f" {'; '.join(const.get_description for const in self.constant_arguments)}; "

            if self.positional_arguments:
                humanized += f" {'; '.join(pos.get_description for pos in self.positional_arguments)}; "

            if self.complex_arguments:
                humanized += f" {'; '.join(compl.get_description for compl in self.complex_arguments)}; "
            humanized = humanized[:-2]

        return humanized
