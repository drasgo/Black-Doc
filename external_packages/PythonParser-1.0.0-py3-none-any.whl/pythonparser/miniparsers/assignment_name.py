from astroid.nodes import AssignName

from pythonparser.models.baseNode import BaseNode
from pythonparser.miniparsers.name import parse_name
from pythonparser.container import Container


def parse_assignment_name(node: AssignName, container: Container) -> BaseNode:
    """Miniparser for Astroid's Assignment Name node.
    The extracted information are saved in the Name node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: AssignName
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    return parse_name(node, container)
