import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.none_type import NoneType


def parse_none(node: astroid.node_classes.NodeNG, container: Container) -> BaseNode:
    """Rollback miniparser for when the proper Astroid's node miniparser is not yet implemented.
    The extracted information are saved in the NoneType node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.node_classes.NodeNG
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = NoneType()
    data_model.initialization(container, node)

    data_model.final_operations()
    return data_model
