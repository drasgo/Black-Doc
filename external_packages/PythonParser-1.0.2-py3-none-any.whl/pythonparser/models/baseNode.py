from dataclasses import field, dataclass
from typing import List, Tuple

from astroid.node_classes import NodeNG

from dataclasses_json import dataclass_json
from pythonparser.mini_parsers_factory import get_mini_parser_by_node


class context_scopes:
    CLASS = "class"
    INNER_CLASS = "inner_class"
    CLASS_METHOD = "class_method"
    INNER_METHOD = "inner_method"
    FUNCTION = "function"
    INNER_FUNCTION = "inner_function"


@dataclass_json
@dataclass
class BaseNode:
    description: str = ""
    context: dict = field(default_factory=dict)
    complete_context: List[dict] = field(default_factory=list)
    element_categories: List[str] = field(default_factory=list)
    context_scope: str = ""
    genus: str = ""
    total_lines: int = -1
    start_line: int = -1
    end_line: int = -1

    cached_dictionary = None
    node = None
    container = None

    def initialization(self, container, node: NodeNG):
        self.container = container
        self.node = node

    def start_end_lines(self) -> Tuple[int, int]:
        """Looks for the starting and ending lines from the astroid node (if given)"""
        if self.node:
            start_line = self.node.fromlineno
            start_line = start_line if start_line else -1

            end_line = self.node.tolineno
            end_line = end_line if end_line else -1
            return start_line, end_line
        else:
            return self.start_line, self.end_line

    def add_current_context(self, name: str):
        """Add node as new context layer"""
        # Possible current contexts are shown in context_scopes
        # If current node is within a class
        if any(
            cont.get("type", "") in ["class", "inner_class"]
            for cont in self.container.get_context()
        ):
            # If it is a class -> it is an inner class
            if self.genus == "class":
                self.genus = context_scopes.INNER_CLASS
            # If it is a function
            else:
                # if it is within another class method -> it is an inner method
                if any(
                    cont.get("type", "") in ["class_method", "inner_method"]
                    for cont in self.container.get_context()
                ):
                    self.genus = context_scopes.INNER_METHOD
                # Otherwise it is a normal class method
                else:
                    self.genus = context_scopes.CLASS_METHOD
        # If it is a function within another function -> it is an inner function
        elif self.genus == "function" and any(
            cont.get("type", "") in ["function", "inner_function"]
            for cont in self.container.get_context()
        ):
            self.genus = context_scopes.INNER_FUNCTION

        # if self.genus == "function" and  any("class" in cont["type"] for cont in self.container.get_context()):
        #     elem_type = "class_method"
        # else:
        #     elem_type = self.genus

        self.container.add_context({"name": name, "type": self.genus})

    def add_context_information(self, result: dict, key: str):
        """Add supplementary information to the current context layer"""
        context = self.container.get_context()
        if key in context[-1] and context[-1][key]:
            context[-1][key].append(result)
        else:
            context[-1][key] = [result]
        self.container.set_context(context)

    def remove_current_context(self):
        """Removes current node from context layer"""
        if self.container.get_context():
            self.container.remove_current_context()

    def get_complete_context(self) -> List[dict]:
        complete_context = list()

        context_chain_link_name = self.name if "name" in self.__annotations__ else ""
        context_chain_link_kind = self.genus

        for c in reversed(self.container.get_context()):
            complete_context.append(
                {
                    "context": {
                        "name": c.get("name"),
                        "type": c.get("type", "") if c.get("type") else "global",
                    },
                    "name": context_chain_link_name,
                    "kind": context_chain_link_kind,
                }
            )
            context_chain_link_name = c.get("name")
            context_chain_link_kind = c.get("type") if c.get("type") else "global"

        return complete_context

    def add_meta_information(self):
        """
        Add any meta information (present in every node) to the object. The values added here are:
        - start_line
        - end_line
        - total_lines
        - complete_context
        - context_scope
        - context
        - description
        """
        self.start_line, self.end_line = self.start_end_lines()
        self.total_lines = self.end_line - self.start_line + 1

        context = self.container.get_context()
        self.complete_context = self.get_complete_context()
        self.context_scope = self.container.get_context_scope()
        self.context = {
            "context_type": context[-1]["type"] if context[-1]["type"] else "global",
            "context_name": context[-1]["name"],
        }

        if self.container.get_description_flag():
            self.extract_description()

    def additional_final_operations(self):
        pass

    def final_operations(self):
        """
        This function adds the meta information present in every parsed node, and allows to run some additional
        operations by overriding the additional_operations method.
        Note: this has to be the last statement executed before returning the current parsed node
        """
        self.add_meta_information()
        self.additional_final_operations()

    def to_human(self) -> str:
        """Overriden by miniparsers"""
        humanized = ""
        return humanized

    def extract_description(self):
        self.description = self.to_human()

    @property
    def get_description(self) -> str:
        if not self.description:
            self.extract_description()
        return self.description

    def parse_node(self, node: NodeNG):
        """
        To avoid circular imports, this static method is in charge of recursively parsing
        a node from any current node, and returns the parsed subtree.

        :param node: Astroid node to be parsed
        :type node: NodeNG
        :returns: BaseNode - The parsed node
        """
        parser = get_mini_parser_by_node(node)
        return parser(node, self.container)
