import isort


def isort_file(file_path: str):
    """
    This method is XXX . It is a global method.

    :param file_path: XXX
    :type file_path: str
    """

    isort.code(file_path)
