import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.dict_unpack import DictUnpack


def parse_dict_unpack(node: astroid.nodes.DictUnpack, container: Container) -> BaseNode:
    """Miniparser for Astroid's Dictionary Unpack nodes.
	The extracted information are saved in the DictUnpack node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: astroid.nodes.DictUnpack
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = DictUnpack()
    data_model.initialization(container, node)

    data_model.node_as_string = node.as_string()

    data_model.final_operations()
    return data_model
