from dataclasses import field, dataclass
from typing import List

from pythonparser.container import Container
from pythonparser.models.baseNode import BaseNode

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class ListContainer(BaseNode):
    genus: str = "list"
    element_categories: List[str] = field(
        default_factory=lambda: ["values_container", "data_structure"]
    )
    elements: List[Container.every_node] = field(default_factory=list)
    node_as_string: str = ""

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        if self.elements:
            humanized = f"list containing {len(self.elements)} elements ('{self.node.as_string()}')"

        else:
            humanized = "empty list"
        return humanized
