from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Imports:
    name: str
    alias: str
    source_path: str

    def __init__(self, name, alias, source_path):
        self.name = name
        self.alias = alias
        self.source_path = source_path


@dataclass_json
@dataclass
class Import(BaseNode):
    """
    Import = {
        "imports": [ {
                       "name": str,
                       "alias": str,
                       "source_path": str
                       },
                    ],
        ... }

    Which should be more straightforward

    """

    imports: List[Imports] = field(default_factory=list)
    is_subset: bool = False
    is_relative_import: bool = False
    nesting_level: int = field(default=0)
    genus: str = "import"

    def additional_final_operations(self):
        """
        Performs few final operations before leaving the current node.
        Ass the import node to the container.
        """
        self.container.add_import(self)

    def to_human(self) -> str:
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = ""
        humanized += " and ".join(
            (f"from the library {imp.source_path}, " if imp.source_path else "")
            + f'the module {(imp.name if imp.name != "*" else "everything")} is imported'
            + (" as " + imp.alias if imp.alias else "")
            for imp in self.imports
        )
        return humanized
