from typing import Union

from astroid.nodes import Attribute, DelAttr
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.attribute import AttributeName


def parse_attribute(
    node: Union[Attribute, DelAttr], container: Container, attrs: AttributeName = None
) -> BaseNode:
    """Miniparser for Astroid's Attribute or DelAttr nodes.
    The extracted information are saved in the AttributeName node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: Union[Attribute, DelAttr]
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :param attrs:
    :type attrs: AttributeName
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    if attrs:
        data_model = attrs
        data_model.name = attrs.name
    else:
        data_model = AttributeName()
        data_model.initialization(container, node)

        data_model.name = node.attrname
        data_model.node_string = node.as_string()

    for child in node.get_children():
        parsed = data_model.parse_node(child)

        if parsed is not None and "node_string" in parsed.__annotations__:
            attrname = parsed.node_string
            if not attrname in data_model.source_path:
                data_model.source_path.append(attrname)

        else:
            if parsed is not None and "name" in parsed.__annotations__:
                attrname = parsed.name

            elif parsed is not None and "value" in parsed.__annotations__:
                attrname = parsed.value

            else:
                attrname = parsed

            if not attrname in data_model.source_path:
                data_model.source_path.append(attrname)

            if child.get_children():
                data_model = parse_attribute(child, container, data_model)

    data_model.final_operations()
    return data_model
