from astroid.nodes import Ellipsis

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.constant import Constant


def parse_ellipsis(node: Ellipsis, container: Container) -> BaseNode:
    """Miniparser for Astroid's Ellipsis nodes.
	The extracted information are saved in the Constant node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: Ellipsis
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Constant()
    data_model.initialization(container, node)

    data_model.value = "..."
    data_model.genus += "ellipsis"

    data_model.final_operations()
    return data_model
