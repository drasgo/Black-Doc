from dataclasses import field, dataclass

from typing import List

from pythonparser.models.baseNode import BaseNode

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Name(BaseNode):
    name: str = str()
    genus: str = "variable"
    element_categories: List[str] = field(
        default_factory=lambda: ["identifiers", "names"]
    )
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["bindings", "references"]
    )

    def to_human(self) -> str:
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"variable @{self.name}@"
        return humanized
