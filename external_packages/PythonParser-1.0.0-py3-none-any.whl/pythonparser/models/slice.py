from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Slice(BaseNode):
    genus: str = "slice"
    element_categories: List[str] = field(
        default_factory=lambda: ["values_container_slice", "iterable_traversal"]
    )
    start: Container.every_node = None
    end: Container.every_node = None
    step: Container.every_node = None
    index: Container.every_node = None

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = "sliced from "

        if self.start.genus == "none_type":
            humanized += "the beginning"
        else:
            humanized += f"{self.start.get_description}"

        humanized += " to "

        if self.end.genus == "none_type":
            humanized += "the end"
        else:
            humanized += f"{self.end.get_description}"

        humanized += ", with step "

        if self.step.genus == "none_type":
            humanized += "one"
        else:
            humanized += f"{self.step.get_description}"

        if self.index:
            humanized += f', with index "{self.index.get_description}"'

        return humanized
