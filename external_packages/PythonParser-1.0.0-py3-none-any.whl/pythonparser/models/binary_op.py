import re
from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json

OP = {
    "+": "sum",
    "-": "subtraction",
    "*": "multiplication",
    "/": "division",
    "**": "power",
}


@dataclass_json
@dataclass
class BinaryOperation(BaseNode):
    op: str = str()
    genus: str = "binary_operation"
    element_categories: List[str] = field(
        default_factory=lambda: ["arithmetic", "binary"]
    )
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["strings", "numbers"]
    )
    operation_as_string: str = ""
    left_hand: Container.every_node = None
    right_hand: Container.every_node = None

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        description_left = re.sub(r"\([^()]*\)", "", self.left_hand.get_description)
        description_right = re.sub(r"\([^()]*\)", "", self.right_hand.get_description)
        humanized = (
            f"%%{OP.get(self.op, '')}%% operation with operators: \"{description_left}\"; "
            f'"{description_right}"( = {self.operation_as_string} )'
        )

        return humanized
