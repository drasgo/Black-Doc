import astroid
from pythonparser.miniparsers.exec_statement import parse_exec
from pythonparser.miniparsers.call import parse_call
from pythonparser.miniparsers.attribute import parse_attribute
from pythonparser.miniparsers.assignment import parse_assignment
from pythonparser.miniparsers.assignment_name import parse_assignment_name
from pythonparser.miniparsers.assignment_attribute import parse_assignment_attribute
from pythonparser.miniparsers.del_name import parse_del_name
from pythonparser.miniparsers.name import parse_name
from pythonparser.miniparsers.arguments import parse_arguments
from pythonparser.miniparsers.assert_statement import parse_assert
from pythonparser.miniparsers.ann_assign import parse_ann_assign
from pythonparser.miniparsers.augmented_assignment import parse_augmented_assignment
from pythonparser.miniparsers.bin_op import parse_bin_op
from pythonparser.miniparsers.bool_op import parse_bool_op
from pythonparser.miniparsers.break_statement import parse_break
from pythonparser.miniparsers.compare import parse_compare
from pythonparser.miniparsers.list_comprehension import parse_list_comprehension
from pythonparser.miniparsers.const import parse_const
from pythonparser.miniparsers.continue_statement import parse_continue
from pythonparser.miniparsers.decorators import parse_decorators
from pythonparser.miniparsers.delattr import parse_delattr
from pythonparser.miniparsers.delete import parse_delete
from pythonparser.miniparsers.dict import parse_dict
from pythonparser.miniparsers.expr import parse_expr
from pythonparser.miniparsers.gen_expr import parse_generator_expr
from pythonparser.miniparsers.ellipsis import parse_ellipsis
from pythonparser.miniparsers.empty_node import parse_empty_node
from pythonparser.miniparsers.except_handler import parse_except_handler

# from pythonparser.lib.miniparsers.v0.ext_slice import parse_ext_slice
from pythonparser.miniparsers.for_statement import parse_for
from pythonparser.miniparsers.async_for import parse_async_for
from pythonparser.miniparsers.await_keyword import parse_await
from pythonparser.miniparsers.import_from import parse_import_from
from pythonparser.miniparsers.global_modifier import parse_global
from pythonparser.miniparsers.if_statement import parse_if
from pythonparser.miniparsers.if_exp import parse_if_exp
from pythonparser.miniparsers.import_statement import parse_import
from pythonparser.miniparsers.index import parse_index
from pythonparser.miniparsers.keyword_modifier import parse_keyword
from pythonparser.miniparsers.list import parse_list
from pythonparser.miniparsers.nonlocal_modifier import parse_nonlocal
from pythonparser.miniparsers.pass_statement import parse_pass
from pythonparser.miniparsers.raise_statement import parse_raise
from pythonparser.miniparsers.return_statement import parse_return
from pythonparser.miniparsers.set_data import parse_set
from pythonparser.miniparsers.slice_data import parse_slice
from pythonparser.miniparsers.starred import parse_starred
from pythonparser.miniparsers.subscript import parse_subscript
from pythonparser.miniparsers.try_except import parse_try_except
from pythonparser.miniparsers.try_finally import parse_try_finally
from pythonparser.miniparsers.tuple import parse_tuple
from pythonparser.miniparsers.unary_op import parse_unary_op
from pythonparser.miniparsers.while_keyword import parse_while
from pythonparser.miniparsers.with_keyword import parse_with
from pythonparser.miniparsers.async_with import parse_async_with
from pythonparser.miniparsers.yield_statement import parse_yield
from pythonparser.miniparsers.yield_from import parse_yield_from
from pythonparser.miniparsers.dict_unpack import parse_dict_unpack
from pythonparser.miniparsers.formatted_value import parse_formatted_value
from pythonparser.miniparsers.joined_str import parse_joined_str
from pythonparser.miniparsers.unknown import parse_unknown
from pythonparser.miniparsers.class_definition import parse_class
from pythonparser.miniparsers.method_definition import parse_method
from pythonparser.miniparsers.dict_comprehension import parse_dict_comprehension


parser_methods = {
    astroid.nodes.Call: parse_call,
    astroid.nodes.Attribute: parse_attribute,
    astroid.nodes.AssignAttr: parse_assignment_attribute,
    astroid.nodes.Assign: parse_assignment,
    astroid.nodes.AssignName: parse_assignment_name,
    astroid.nodes.ClassDef: parse_class,
    astroid.nodes.FunctionDef: parse_method,
    astroid.nodes.DelName: parse_del_name,
    astroid.nodes.Name: parse_name,
    astroid.nodes.Arguments: parse_arguments,
    astroid.nodes.Assert: parse_assert,
    astroid.nodes.AnnAssign: parse_ann_assign,
    astroid.nodes.AugAssign: parse_augmented_assignment,
    astroid.nodes.BinOp: parse_bin_op,
    astroid.nodes.BoolOp: parse_bool_op,
    astroid.nodes.Break: parse_break,
    astroid.nodes.Compare: parse_compare,
    astroid.nodes.Comprehension: parse_list_comprehension,
    astroid.nodes.DictComp: parse_dict_comprehension,
    astroid.nodes.Const: parse_const,
    astroid.nodes.Continue: parse_continue,
    astroid.nodes.Decorators: parse_decorators,
    astroid.nodes.DelAttr: parse_delattr,
    astroid.nodes.Delete: parse_delete,
    astroid.nodes.Dict: parse_dict,
    astroid.nodes.Expr: parse_expr,
    astroid.nodes.Ellipsis: parse_ellipsis,
    astroid.nodes.EmptyNode: parse_empty_node,
    astroid.nodes.ExceptHandler: parse_except_handler,
    astroid.nodes.Exec: parse_exec,
    # astroid.nodes.ExtSlice: parse_ext_slice, Deprecated
    astroid.nodes.For: parse_for,
    astroid.nodes.AsyncFor: parse_async_for,
    astroid.nodes.Await: parse_await,
    astroid.nodes.ImportFrom: parse_import_from,
    astroid.nodes.Global: parse_global,
    astroid.nodes.If: parse_if,
    astroid.nodes.IfExp: parse_if_exp,
    astroid.nodes.Import: parse_import,
    astroid.nodes.Index: parse_index,
    astroid.nodes.Keyword: parse_keyword,
    astroid.nodes.List: parse_list,
    astroid.nodes.Nonlocal: parse_nonlocal,
    astroid.nodes.Pass: parse_pass,
    astroid.nodes.Raise: parse_raise,
    astroid.nodes.Return: parse_return,
    astroid.nodes.Set: parse_set,
    astroid.nodes.Slice: parse_slice,
    astroid.nodes.Starred: parse_starred,
    astroid.nodes.Subscript: parse_subscript,
    astroid.nodes.TryExcept: parse_try_except,
    astroid.nodes.TryFinally: parse_try_finally,
    astroid.nodes.Tuple: parse_tuple,
    astroid.nodes.UnaryOp: parse_unary_op,
    astroid.nodes.While: parse_while,
    astroid.nodes.With: parse_with,
    astroid.nodes.AsyncWith: parse_async_with,
    astroid.nodes.Yield: parse_yield,
    astroid.nodes.YieldFrom: parse_yield_from,
    astroid.nodes.DictUnpack: parse_dict_unpack,
    astroid.nodes.FormattedValue: parse_formatted_value,
    astroid.nodes.JoinedStr: parse_joined_str,
    astroid.scoped_nodes.GeneratorExp: parse_generator_expr,
    astroid.nodes.Unknown: parse_unknown,
}
