from astroid.nodes import DelAttr

from pythonparser.models.baseNode import BaseNode
from pythonparser.miniparsers.attribute import parse_attribute
from pythonparser.container import Container


def parse_delattr(node: DelAttr, container: Container) -> BaseNode:
    """Miniparser for Astroid's DelAttr nodes.
	The extracted information are saved in the AttributeName node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: DelAttr
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    return parse_attribute(node, container)
