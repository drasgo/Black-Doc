import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.try_except import TryExcept
from pythonparser.miniparsers.except_handler import parse_except_handler


def parse_try_except(node: astroid.nodes.TryExcept, container: Container) -> BaseNode:
    """Miniparser for Astroid's Try-Except node.
    The extracted information are saved in the TryExcept node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.TryExcept
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    return try_except_model(node, container)


def try_except_model(node: astroid.nodes.TryExcept, container: Container) -> BaseNode:
    """Model for parsing try base Astroid nodes.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.TryExcept
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = TryExcept()
    data_model.initialization(container, node)
    print("yo")
    for statement in node.body:
        data_model.try_block.append(data_model.parse_node(statement))

    for handler in node.handlers:
        parsed_handler = parse_except_handler(handler, container)
        data_model.exception = parsed_handler

    for alternative in node.orelse:
        data_model.orelse_block.append(data_model.parse_node(alternative))

    data_model.final_operations()
    return data_model
