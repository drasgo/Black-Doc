import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.index import Index


def parse_index(node: astroid.nodes.Index, container: Container) -> BaseNode:
    """Miniparser for Astroid's Index node.
    The extracted information are saved in the Index node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.Index
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Index()
    data_model.initialization(container, node)

    parsed = data_model.parse_node(node.value)
    data_model.value = parsed
    if "value" in parsed.__annotations__:
        data_model.name = parsed.value
    elif "name" in parsed.__annotations__:
        data_model.name = parsed.name
    else:
        data_model.name = ""

    data_model.final_operations()
    return data_model
