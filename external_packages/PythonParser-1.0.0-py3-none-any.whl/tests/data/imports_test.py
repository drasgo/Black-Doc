from a import b

# import .r.w
# import ..a.b.c
from x.y import z
from x.y.z import f
from .p.q.r import s
from ..g.f.o import e
from l.m.n import o as O
import X
