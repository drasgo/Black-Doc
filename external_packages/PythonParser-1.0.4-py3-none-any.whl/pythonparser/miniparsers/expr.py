import astroid
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.expr import Expr


def parse_expr(node: astroid.nodes.Expr, container: Container) -> BaseNode:
    """Miniparser for Astroid's Expression node.
    The extracted information are saved in the Expr node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.Expr
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Expr()
    data_model.initialization(container, node)

    data_model.value = data_model.parse_node(node.value)

    data_model.final_operations()
    return data_model
