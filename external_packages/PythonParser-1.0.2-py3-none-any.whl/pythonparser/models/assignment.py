from dataclasses import field, dataclass

from typing import List

from pythonparser.models.call import Call
from dataclasses_json import dataclass_json
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container


OP = {
    "+=": "plus",
    "-=": "minus",
    "*=": "times",
    "/=": "divided by",
    "**=": "to the power of",
}


@dataclass_json
@dataclass
class Assignment(BaseNode):
    assignees: List[Container.every_node] = field(default_factory=list)
    assignee_annotation: Container.every_node = None
    assigned_value: Container.every_node = None
    genus: str = "value_assignment"
    element_categories: List[str] = field(
        default_factory=lambda: ["storage", "value_pass"]
    )
    element_sub_categories: List[str] = field(default_factory=list)
    is_attribute: bool = False
    is_augmented: bool = False
    origin_class: str = ""
    origin_method: str = ""
    op: str = str()

    def additional_final_operations(self):
        """Performs few final operations before leaving the current node.
        Adding information related to class/object attributes to temporary placeholder, so it can be accessed
        later on by the parent class. To do so, for class attribute checks if the context is class.
        Then, if it's not in a method, it has to be a class variable
        """

        self.origin_class, self.origin_method = (
            self.container.get_current_class_method()
        )
        self.container.add_assignment(self)

        if self.container.get_context()[-1]["type"] == "class":
            for assignee in [
                assignee for assignee in self.assignees if assignee.genus == "variable"
            ]:
                # annotation = "" if not self.assignee_annotation or "name" not in self.assignee_annotation.__annotations__ \
                #     else self.assignee_annotation.name
                self.container.add_current_class_attribute(
                    {
                        "class": self.container.get_context()[-1]["name"],
                        "label": assignee.name,
                        "description": assignee.get_description if self.container.get_description_flag() else "",
                        "genus": self.genus,
                        "complete_context": assignee.complete_context,
                        "start_line": assignee.start_line,
                        "end_line": assignee.end_line,
                    }
                )
        # For object attribute, checks if it starts with "self" and if it's in a class method
        elif self.container.get_context()[-1]["type"] in [
            "class_method",
            "inner_method",
        ]:
            for assignee in [
                assignee
                for assignee in self.assignees
                if assignee.genus == "attribute" and assignee.source_path[-1] == "self"
            ]:
                cls_name, _ = self.container.get_current_class_method()
                self.container.add_current_object_attribute(
                    {
                        "class": cls_name,
                        "label": assignee.node_string,
                        "description": assignee.get_description,
                        "complete_context": assignee.complete_context,
                        "start_line": assignee.start_line,
                        "end_line": assignee.end_line,
                    }
                )

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        if self.assigned_value.genus == "call":
            assert isinstance(self.assigned_value, Call)
            humanized = (
                f'The value returned by the execution of the function "'
                f'{self.assigned_value.node_string.lower()}"'
            )
        else:
            humanized = f"The {self.assigned_value.get_description}"

        if self.op and self.op in OP:
            humanized += " " + OP[self.op] + " the assignee"

        humanized += (
            (" is " if len(self.assignees) == 1 else " are ") + "assigned to the "
            f"{' and the '.join([assign.get_description for assign in self.assignees])}"
        )

        if self.assignee_annotation:
            humanized += f", of type {self.assignee_annotation.get_description}"

        humanized += "."
        return humanized
