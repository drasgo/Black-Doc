def f_out(out: str):
    """
	Containing nested function
	"""

    def f_in(x: int):
        """
		A nested function
		"""
        return str(int) + out

    return f_in(26)
