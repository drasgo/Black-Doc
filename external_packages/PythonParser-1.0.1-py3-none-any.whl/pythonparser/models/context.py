from dataclasses import dataclass, field
from typing import Optional
from pythonparser.models.baseNode import BaseNode


@dataclass
class Context(BaseNode):
    name: Optional[str] = field(default_factory=str)
    kind: Optional[str] = field(default_factory=str)
    module: Optional[str] = field(default_factory=str)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node

        TODO: implement here"""
        humanized = ""
        return humanized


if __name__ == "__main__":
    context = Context(name="global", kind="module", module="main")
    print(context.to_json())
    print(f"Context name: {context.name}")
    print(f"Conext type: {context.kind}")
    context.kind = "class"
    print(f"Changed context type to: {context.kind}")
