from astroid.exceptions import AstroidError
from os import path
from .parsepy.tests import pipe_analysis
import astroid


def my_min(n, threshold=3):
    import time

    print(time.time())
    return min(n, threshold)


class Foo:
    a_class_variable = my_min(5)

    def __init__(self):
        from os.path import isdir
        from ..parsepy.parsepy.parsepy import Parser

        class Moo:
            from json import loads

            marrone = loads({"moo": "marrone"})

            def __init__(self):
                self.my_moo = "marrone!"

        self.grass = "chew"
        self.moo = Moo()

    def a_class_method(self, m):
        x = my_min(m, threshold=Foo.a_class_variable)
        return x + Foo.a_class_variable


def method_with_class(x):
    class Foo:
        def __init__(self, r):
            self.y = r + x

        def get_y(self):
            return self.y

    f = Foo(r=13)
    return f.get_y()
