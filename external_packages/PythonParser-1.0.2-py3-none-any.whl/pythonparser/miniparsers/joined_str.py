from astroid.nodes import JoinedStr

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.joined_string import JoinedString


def parse_joined_str(node: JoinedStr, container: Container) -> BaseNode:
    """Miniparser for Astroid's Joined String node.
	The extracted information are saved in the JoinedString node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: JoinedStr
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = JoinedString()
    data_model.initialization(container, node)

    data_model.string = node.as_string()
    for element in node.values:
        data_model.values.append(data_model.parse_node(element))

    data_model.final_operations()
    return data_model
