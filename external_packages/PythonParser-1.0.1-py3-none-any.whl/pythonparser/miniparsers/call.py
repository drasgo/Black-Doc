import astroid
from pythonparser.models.binary_op import BinaryOperation
from pythonparser.models.name import Name
from pythonparser.models.constant import Constant
from pythonparser.models.keyword_argument import KeywordArgument
from pythonparser.models.attribute import AttributeName

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.call import Call


def parse_call(node: astroid.nodes.Call, container: Container) -> BaseNode:
    """Miniparser for Astroid's Call node.
    The extracted information are saved in the Call node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.Call
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Call()
    data_model.initialization(container, node)

    args = node.args if node.args else []
    key = node.keywords if node.keywords else []

    data_model.node_string = str(node.as_string())
    data_model.add_current_context(data_model.node_string)

    called = node.func.as_string().split(".")
    data_model.name = called[-1]
    data_model.source_path = called[:-1] if len(called) > 1 else []

    arguments_string = []

    for child in args + key:
        if child is None:
            arguments_string.append({"name": None, "element_type": "constant None"})
        else:
            parsed_node = data_model.parse_node(child)
            arguments_string.append(
                {
                    "name": str(child.as_string()).translate(
                        str.maketrans("", "", "'\"")
                    ),
                    "element_type": parsed_node.genus,
                }
            )

        parsed_node = data_model.parse_node(child)
        if not parsed_node:
            return data_model

        element_type = parsed_node.genus

        if funcs_dict is not None and element_type in funcs_dict:
            func_call = funcs_dict[element_type]
            func_call(data_model, parsed_node)
        else:
            data_model.arguments_count = +1
            # parsed_node['position'] = data_model.arguments_count
            data_model.positional_arguments.append(parsed_node)

    data_model.arguments_string = arguments_string
    data_model.remove_current_context()
    data_model.final_operations()

    return data_model


def extract_attribute_from_dict(call_class: Call, attribute_dict: AttributeName):
    """Add the AttributeName node as positional argument to the call

    :param call_class: Call node object
    :type call_class: Call
    :param attribute_dict: single call attribute
    :type attribute_dict: AttributeName
    """
    call_class.arguments_count += 1
    call_class.positional_arguments.append(attribute_dict)


def extract_name_from_dict(call_class: Call, name_dict: Name):
    """Add the Name node as positional argument or name of the call

    :param call_class: Call node object
    :type call_class: Call
    :param name_dict: single call attribute
    :type name_dict: Name
    """
    if not call_class.name:
        call_class.name = name_dict.name

    else:
        call_class.arguments_count += 1
        call_class.positional_arguments.append(name_dict)


def extract_keyword_from_dict(call_class: Call, keyword_dict: KeywordArgument):
    """Add the KeywordArgument node as keyword argument or name of the call

    :param call_class: Call node object
    :type call_class: Call
    :param keyword_dict: single call attribute
    :type keyword_dict: KeywordArgument
    """
    call_class.arguments_count += 1
    call_class.keyword_arguments.append(keyword_dict)


def extract_constant_from_dict(call_class: Call, constant_dict: Constant):
    """Add the Constant node as constant argument or name of the call

    :param call_class: Call node object
    :type call_class: Call
    :param constant_dict: single call attribute
    :type constant_dict: Constant
    """
    call_class.arguments_count += 1
    call_class.constant_arguments.append(constant_dict)


def extract_binop_from_dict(call_class: Call, binop_dict: BinaryOperation):
    """Add the BinaryOperation node as complex argument or name of the call

    :param call_class: Call node object
    :type call_class: Call
    :param binop_dict: single call attribute
    :type binop_dict: BinaryOperation
    """
    call_class.arguments_count += 1
    call_class.complex_arguments.append(binop_dict)


funcs_dict = {
    "attribute": extract_attribute_from_dict,
    "keyword": extract_keyword_from_dict,
    "constant": extract_constant_from_dict,
    "name": extract_name_from_dict,
    "binary_operation": extract_binop_from_dict,
}
