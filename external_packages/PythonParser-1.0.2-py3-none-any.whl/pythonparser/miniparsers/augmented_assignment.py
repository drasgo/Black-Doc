from astroid.nodes import AugAssign
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.assignment import Assignment


def parse_augmented_assignment(node: AugAssign, container: Container) -> BaseNode:
    """Miniparser for Astroid's Augmented Assignment node.
    The extracted information are saved in the Assignment node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: AugAssign
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Assignment()
    data_model.initialization(container, node)

    data_model.assignees.append(data_model.parse_node(node.target))
    data_model.assigned_value = data_model.parse_node(node.value)

    data_model.op = node.op
    data_model.is_augmented = True

    data_model.final_operations()
    return data_model
