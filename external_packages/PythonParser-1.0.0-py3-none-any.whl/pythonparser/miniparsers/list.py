from astroid.nodes import List

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.list import ListContainer


def parse_list(node: List, container: Container) -> BaseNode:
    """Miniparser for Astroid's List node.
    The extracted information are saved in the ListContainer node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: List
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = ListContainer()
    data_model.initialization(container, node)

    for child in node.elts:
        data_model.elements.append(data_model.parse_node(child))

    data_model.final_operations()
    return data_model
