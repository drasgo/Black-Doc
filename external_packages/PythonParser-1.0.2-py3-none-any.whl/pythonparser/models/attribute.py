from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class AttributeName(BaseNode):
    name: str = None
    genus: str = "attribute"
    element_categories: List[str] = field(
        default_factory=lambda: ["structural", "identifier"]
    )
    source_path: List[str] = field(default_factory=list)
    node_string: str = ""

    def to_human(self) -> str:
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        source_element = ""
        temp_source = self.source_path.copy()
        temp_source.reverse()
        for source in temp_source:
            source_element += str(source) + "."
        source_element = source_element[:-1]

        humanized = f" attribute @{self.name}@{' from object/module ' + source_element if temp_source else ''} "
        source_element += "." + str(self.name)
        humanized += f"({self.node_string})"

        return humanized
