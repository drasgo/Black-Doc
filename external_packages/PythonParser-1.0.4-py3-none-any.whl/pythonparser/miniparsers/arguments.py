import astroid
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.arguments import Arguments


def parse_arguments(node: astroid.nodes.Arguments, container: Container) -> BaseNode:
    """Miniparser for Astroid's Arguments node.
    The extracted information are saved in the Arguments node, which is recursively returned to the parent node.

    :param node: Astroid node to be parsed
    :type node: astroid.nodes.Arguments
    :param container: Container used for holding parsed and extracted information.
    :type container: Container
    :returns: BaseNode - Current parsed node, returned to its parent
    """
    data_model = Arguments()
    data_model.initialization(container, node)

    for child in node.get_children():
        data_model.components.append(data_model.parse_node(child))

    data_model.final_operations()
    return data_model
