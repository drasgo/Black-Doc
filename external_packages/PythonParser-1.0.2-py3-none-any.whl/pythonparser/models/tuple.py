from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class TupleContainer(BaseNode):
    genus: str = "tuple"
    arity: int = 0
    element_categories: List[str] = field(
        default_factory=lambda: ["values_container", "data_structure"]
    )
    elements: List[Container.every_node] = field(default_factory=list)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"tuple containing {str(self.arity)} items"
        return humanized
