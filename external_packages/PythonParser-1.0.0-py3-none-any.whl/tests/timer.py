import time


def what_time_is_it():
    return time.time()


class ClassCommon:
    """
	This class appears with the same name and methods in another module
	"""

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def product(self):
        return x * y * z


def f(x, y):
    return x * y + x * x
