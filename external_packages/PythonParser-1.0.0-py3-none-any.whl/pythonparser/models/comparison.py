from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Comparison(BaseNode):
    genus: str = "comparison"
    element_categories: List[str] = field(
        default_factory=lambda: ["comparison", "boolean"]
    )
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["comparison", "condition"]
    )
    left_hand: Container.every_node = None
    right_hand: Container.every_node = None
    operator: str = str()

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"%%{self.operator}%% comparison between {self.left_hand.description} and {self.right_hand.description}"
        return humanized
