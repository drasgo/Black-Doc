from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class UnaryOperation(BaseNode):
    op: str = str()
    genus: str = "unary_op"
    element_categories: List[str] = field(
        default_factory=lambda: ["arithmetic", "binary"]
    )
    element_sub_categories: List[str] = field(
        default_factory=lambda: ["strings", "numbers"]
    )
    operand: Container.every_node = None

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f"unary operation with operator %%{str(self.op)}%% and operand {str(self.operand.description)}"
        return humanized
