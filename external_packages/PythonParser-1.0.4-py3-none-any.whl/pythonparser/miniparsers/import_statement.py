import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.import_op import Import, Imports


def parse_import(node: astroid.nodes.Import, container: Container) -> BaseNode:
    """Miniparser for Astroid's Import node.
	The extracted information are saved in the Import node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: astroid.nodes.Import
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Import()
    data_model.initialization(container, node)

    for name in node.names:
        imp = name[0].split(".")
        alias = name[1] if name[1] is not None else ""
        source_path = ""
        name = imp[-1]

        if len(imp) > 1:
            source_path += ".".join(imp[:-1])

        current_import = Imports(name=name, alias=alias, source_path=source_path)
        data_model.imports.append(current_import)

    data_model.final_operations()
    return data_model
