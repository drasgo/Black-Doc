from astroid.nodes import EmptyNode

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.empty import Empty


def parse_empty_node(node: EmptyNode, container: Container) -> BaseNode:
    """Miniparser for Astroid's Empty node.
	The extracted information are saved in the Empty node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: EmptyNode
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Empty()
    data_model.initialization(container, node)

    data_model.final_operations()
    return data_model
