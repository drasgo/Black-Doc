from dataclasses import field, dataclass

from typing import List

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class Subscript(BaseNode):
    genus: str = "subscript"
    element_categories: List[str] = field(
        default_factory=lambda: ["values_container_subscript", "index_lookup"]
    )
    partition: Container.every_node = None
    value_contained: Container.every_node = None
    name: str = str()

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = f'value stored at "{self.partition.get_description}" of element "{self.value_contained.get_description}"'
        return humanized
