from dataclasses import field, dataclass

from typing import List
from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class ReturnStatement(BaseNode):
    genus: str = "return"
    element_categories: List[str] = field(
        default_factory=lambda: ["flow_control", "terminate_procedure"]
    )
    return_value: Container.every_node = None
    return_type: str = ""

    return_as_string = ""

    def additional_final_operations(self):
        """
        Performs few final operations before leaving the current node.
        Saves the complete return node and a simplified version of the return node into the container.
        """
        class_identifier, method_identifier = self.container.get_current_class_method()

        self.container.add_return(
            {
                "origin_class": class_identifier,
                "origin_method": method_identifier,
                "context_scope": self.container.get_context()[-1]["type"],
                "start_line": self.start_line,
                "end_line": self.end_line,
                "complete_context": self.get_complete_context(),
                "returned_value": {
                    "element_type": self.return_value.genus,
                    "category": self.return_value.element_categories,
                    "name": self.return_as_string,
                },
            }
        )
        self.container.add_total_return(self)

    def to_human(self):
        """Called if the description flag is True, and thus the description needs to be generated for this node.

        :returns: str - generated description of the current node
        """
        humanized = (
            f"returns the value of the {self.return_value.get_description.lower()}"
        )
        return humanized
