# pylint: disable=C0111
from .domain.commit import Commit, Modification, ModificationType  # noqa
from .repository_mining import RepositoryMining, GitRepository  # noqa

__version__ = "1.15.5"
