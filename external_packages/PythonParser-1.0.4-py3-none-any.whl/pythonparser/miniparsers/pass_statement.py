import astroid

from pythonparser.models.baseNode import BaseNode
from pythonparser.container import Container
from pythonparser.models.pass_statement import Pass


def parse_pass(node: astroid.nodes.Pass, container: Container) -> BaseNode:
    """Miniparser for Astroid's Pass node.
	The extracted information are saved in the Pass node, which is recursively returned to the parent node.

	:param node: Astroid node to be parsed
	:type node: astroid.nodes.Pass
	:param container: Container used for holding parsed and extracted information.
	:type container: Container
	:returns: BaseNode - Current parsed node, returned to its parent
	"""
    data_model = Pass()
    data_model.initialization(container, node)

    data_model.final_operations()
    return data_model
